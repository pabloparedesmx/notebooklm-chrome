# NotebookLM Content Adder

A powerful Chrome extension that intelligently extracts content from any webpage and seamlessly adds it to your NotebookLM notebooks. Transform your web browsing into an efficient research workflow.

## ✨ Features

### 🎯 Smart Content Extraction
- **Intelligent Detection**: Automatically identifies articles, YouTube videos, PDFs, and web pages
- **Advanced Algorithms**: Uses multiple extraction strategies for optimal content quality
- **Content Filtering**: Removes navigation, ads, and irrelevant elements
- **Markdown Support**: Optional conversion to clean Markdown format

### 📚 NotebookLM Integration
- **Seamless Addition**: Add content directly to your NotebookLM notebooks
- **Notebook Selection**: Choose target notebook from dropdown menu
- **Automated Process**: Handles the entire workflow from extraction to addition
- **Progress Tracking**: Real-time status updates and feedback

### 🚀 User Experience
- **Context Menu**: Right-click any page to quickly add content
- **Smart Popup**: Beautiful interface with content preview
- **Auto-Extraction**: Optional automatic content analysis on page load
- **Recent Sources**: Track your recently added content

### ⚙️ Advanced Configuration
- **Comprehensive Settings**: Fine-tune extraction and processing options
- **Default Notebook**: Set preferred notebook for quick additions
- **Content Preferences**: Control what gets included or excluded
- **Backup & Restore**: Export/import your settings

## 🏗️ Architecture

```
notebooklm-extension/
├── manifest.json                 # Extension configuration
├── background/
│   └── service-worker.js         # Background operations & state management
├── content/
│   └── content-script.js         # Page content extraction
├── popup/
│   ├── popup.html               # Main interface
│   ├── popup.js                 # Popup logic & interactions
│   └── popup.css                # Interface styling
├── options/
│   ├── options.html             # Settings page
│   ├── options.js               # Settings management
│   └── options.css              # Settings styling
├── utils/
│   ├── notebooklm-api.js        # NotebookLM automation
│   ├── content-extractor.js     # Advanced content extraction
│   └── storage.js               # Data management
└── assets/
    ├── icons/                   # Extension icons
    └── create-icons.html        # Icon generation tool
```

## 🚀 Installation

### Quick Setup

1. **Download**: Clone or download this repository
2. **Chrome Extensions**: Navigate to `chrome://extensions/`
3. **Developer Mode**: Enable "Developer mode" in the top-right
4. **Load Extension**: Click "Load unpacked" and select the `notebooklm-extension` folder
5. **Generate Icons**: Open `assets/create-icons.html` to create placeholder icons

### Icon Setup

1. Open `assets/create-icons.html` in your browser
2. Click "Generate Icons" to create all required sizes
3. Download and save in `assets/icons/` as:
   - `icon16.png`, `icon32.png`, `icon48.png`, `icon128.png`

## 💡 Usage

### Basic Workflow

1. **Browse**: Visit any webpage with content you want to save
2. **Extract**: Click the extension icon and select "Extract Content"
3. **Preview**: Review the extracted content in the popup
4. **Select**: Choose your target NotebookLM notebook
5. **Add**: Click "Add to NotebookLM" to save the content

### Quick Actions

- **Context Menu**: Right-click → "Add to NotebookLM"
- **Selected Text**: Highlight text and use context menu
- **Auto-Extract**: Enable in settings for automatic content analysis

### Supported Content Types

- 📄 **Articles & Blog Posts**: Smart extraction of main content
- 🎥 **YouTube Videos**: Metadata, descriptions, and video information
- 📋 **PDF Documents**: Direct URL linking and text extraction
- 🌐 **Web Pages**: General content with intelligent filtering
- ✂️ **Selected Text**: Add specific selections from any page

## ⚙️ Configuration

### General Settings
- **Auto-Extract**: Automatically analyze pages on load
- **Content Preview**: Show extraction preview
- **Notebook Behavior**: Keep NotebookLM tab open after adding

### Content Processing
- **Smart Extraction**: Use advanced content detection
- **Filter Navigation**: Remove menus, headers, footers
- **Filter Advertisements**: Remove ads and promotional content
- **Markdown Conversion**: Convert HTML to clean Markdown

### Advanced Options
- **Default Notebook**: Set preferred notebook for quick access
- **Extraction Timeout**: Configure processing time limits
- **Content Length Limits**: Set maximum content size
- **Cache Management**: Control stored data

## 🔧 Technical Details

### Core Technologies
- **Manifest V3**: Latest Chrome extension standard
- **ES2020+**: Modern JavaScript with async/await
- **Chrome APIs**: Storage, tabs, scripting, contextMenus
- **CSS Grid/Flexbox**: Responsive, modern styling

### Content Extraction Strategies
1. **Article Detection**: Multiple heuristics for article identification
2. **Readability Algorithm**: Content scoring and selection
3. **DOM Analysis**: Structural content assessment
4. **Metadata Extraction**: Author, date, description parsing

### NotebookLM Automation
- **DOM Manipulation**: Automated interaction with NotebookLM interface
- **Form Completion**: Intelligent form filling and submission
- **Error Handling**: Robust error detection and recovery
- **State Management**: Progress tracking and status updates

## 🛠️ Development

### Local Development

```bash
# Make changes to source files
# Reload extension in chrome://extensions/
# Test on various websites
```

### Key Components

- **Service Worker** (`background/service-worker.js`): Handles automation and state
- **Content Script** (`content/content-script.js`): Extracts page content
- **Popup Interface** (`popup/`): Main user interaction
- **Options Page** (`options/`): Settings and configuration
- **Utilities** (`utils/`): Core functionality libraries

### Adding Features

1. **Content Extraction**: Modify `utils/content-extractor.js`
2. **UI Components**: Update popup or options interfaces
3. **NotebookLM Integration**: Enhance `utils/notebooklm-api.js`
4. **Storage**: Manage data with `utils/storage.js`

## 🔒 Privacy & Security

### Data Handling
- **Local Storage Only**: All data stored locally in your browser
- **No Data Collection**: Extension doesn't collect or transmit personal data
- **Minimal Permissions**: Only requests necessary browser permissions
- **Open Source**: Full source code available for review

### Permissions Explained
- **activeTab**: Access current webpage for content extraction
- **storage**: Save settings and preferences locally
- **tabs**: Manage NotebookLM automation
- **scripting**: Inject content extraction scripts
- **contextMenus**: Provide right-click menu options

## 🐛 Troubleshooting

### Common Issues

**Extension Not Working**
- Ensure you're on a supported webpage
- Check that NotebookLM is accessible
- Verify extension permissions in Chrome settings

**Content Extraction Failing**
- Try refreshing the page
- Check browser console for errors
- Verify page has extractable content

**NotebookLM Integration Issues**
- Ensure you're logged into NotebookLM
- Check that target notebook exists
- Verify NotebookLM page is fully loaded

### Debug Mode
1. Open Chrome DevTools (F12)
2. Check Console tab for error messages
3. Review Network tab for failed requests
4. Inspect extension background page

## 🤝 Contributing

### Development Setup
1. Fork the repository
2. Make your changes in appropriate files
3. Test thoroughly across different websites
4. Ensure code follows existing patterns
5. Submit pull request with clear description

### Code Style
- Use modern JavaScript (ES2020+)
- Follow existing naming conventions
- Add comments for complex logic
- Maintain consistent indentation
- Test across multiple browsers

## 📋 Version History

### v1.0.0 - Initial Release
- Smart content extraction from web pages
- NotebookLM integration and automation
- Popup interface with notebook selection
- Options page with comprehensive settings
- Context menu integration
- Support for articles, YouTube, PDFs
- Content filtering and processing
- Local storage management

## 📄 License

This project is open source and available under the MIT License. Feel free to modify and distribute according to your needs.

## 🙏 Acknowledgments

- Built for the NotebookLM community
- Inspired by research workflow optimization
- Thanks to all contributors and testers

---

**Ready to transform your research workflow?** Install the NotebookLM Content Adder and start building your knowledge base more efficiently than ever before! 🚀