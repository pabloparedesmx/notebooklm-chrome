// NotebookLM Content Adder - Popup Script
// Handles the main popup interface and user interactions

class PopupController {
  constructor() {
    this.currentTab = null;
    this.notebooks = [];
    this.currentState = 'idle';
    this.lastAddedNotebookUrl = null;
    
    this.initializeElements();
    this.setupEventListeners();
    this.initialize();
  }
  
  initializeElements() {
    // Status elements
    this.statusBadge = document.getElementById('statusBadge');
    this.statusMessage = document.getElementById('statusMessage');
    this.statusIcon = document.getElementById('statusIcon');
    this.statusText = document.getElementById('statusText');
    
    // Page info elements
    this.pageTitle = document.getElementById('pageTitle');
    this.pageUrl = document.getElementById('pageUrl');
    this.contentType = document.getElementById('contentType');
    
    // Notebook selection
    this.notebookSelect = document.getElementById('notebookSelect');
    this.createNotebookSection = document.getElementById('createNotebookSection');
    this.newNotebookName = document.getElementById('newNotebookName');
    this.createNotebookBtn = document.getElementById('createNotebookBtn');
    this.cancelCreateBtn = document.getElementById('cancelCreateBtn');
    
    // Action buttons
    this.addToNotebookBtn = document.getElementById('addToNotebookBtn');
    this.openNotebookBtn = document.getElementById('openNotebookBtn');
    
    // Recent sources
    this.recentSources = document.getElementById('recentSources');
    this.recentSourcesList = document.getElementById('recentSourcesList');
    
    // Footer links
    this.optionsLink = document.getElementById('optionsLink');
    this.helpLink = document.getElementById('helpLink');
  }
  
  setupEventListeners() {
    this.addToNotebookBtn.addEventListener('click', () => this.handleAddToNotebook());
    this.openNotebookBtn.addEventListener('click', () => this.handleOpenNotebook());
    this.notebookSelect.addEventListener('change', () => this.handleNotebookSelection());
    this.optionsLink.addEventListener('click', () => this.openOptionsPage());
    this.helpLink.addEventListener('click', () => this.showHelp());
    
    // Create notebook event listeners
    this.createNotebookBtn.addEventListener('click', () => this.handleCreateNotebook());
    this.cancelCreateBtn.addEventListener('click', () => this.handleCancelCreate());
    this.newNotebookName.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') this.handleCreateNotebook();
      if (e.key === 'Escape') this.handleCancelCreate();
    });
    this.newNotebookName.addEventListener('input', () => this.validateNotebookName());
    
    // Listen for messages from background script
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      this.handleBackgroundMessage(message, sender, sendResponse);
    });
  }
  
  async initialize() {
    try {
      // Get current tab
      await this.getCurrentTab();
      
      // Update page info
      this.updatePageInfo();
      
      // Load notebooks
      await this.loadNotebooks();
      
      // Load recent sources
      await this.loadRecentSources();
      
      // Get extension state
      await this.updateExtensionState();
      
    } catch (error) {
      console.error('Popup initialization failed:', error);
      this.showStatus('error', 'Failed to initialize popup');
    }
  }
  
  async getCurrentTab() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    this.currentTab = tabs[0];
  }
  
  updatePageInfo() {
    if (!this.currentTab) return;
    
    this.pageTitle.textContent = this.currentTab.title || 'Untitled';
    this.pageUrl.textContent = this.currentTab.url;
    
    // Detect content type based on URL
    const contentType = this.detectContentType(this.currentTab.url);
    this.contentType.textContent = contentType;
    this.contentType.className = `content-type ${contentType}`;
    
    // Check for paywall and show warning if detected
    this.checkAndShowPaywallWarning();
  }
  
  detectContentType(url) {
    if (url.includes('youtube.com/watch')) return 'youtube';
    if (url.includes('.pdf')) return 'pdf';
    if (url.includes('wikipedia.org')) return 'article';
    if (url.includes('medium.com') || url.includes('substack.com')) return 'article';
    return 'webpage';
  }
  
  detectPaywall(url, title) {
    // Common paywall indicators
    const paywallSites = [
      'nytimes.com', 'wsj.com', 'ft.com', 'economist.com',
      'washingtonpost.com', 'newyorker.com', 'atlantic.com',
      'bloomberg.com', 'reuters.com', 'techcrunch.com',
      'wired.com', 'medium.com', 'substack.com', 'hbr.org',
      'harvard.edu', 'foreignaffairs.com', 'foreignpolicy.com',
      'nature.com', 'science.org', 'nationalgeographic.com',
      'spectator.co.uk', 'thetimes.co.uk', 'telegraph.co.uk'
    ];
    
    const paywallKeywords = [
      'subscribe', 'premium', 'member', 'unlock', 'paywall',
      'sign up', 'free trial', 'subscription'
    ];
    
    // Check if URL contains known paywall sites
    const domain = new URL(url).hostname.toLowerCase();
    const isPaywallSite = paywallSites.some(site => domain.includes(site));
    
    // Check title for paywall keywords
    const titleLower = (title || '').toLowerCase();
    const hasPaywallKeywords = paywallKeywords.some(keyword => 
      titleLower.includes(keyword)
    );
    
    return {
      isPotentialPaywall: isPaywallSite || hasPaywallKeywords,
      confidence: isPaywallSite ? 'high' : hasPaywallKeywords ? 'medium' : 'low',
      reason: isPaywallSite ? 'Known paywall site' : hasPaywallKeywords ? 'Contains subscription keywords' : null
    };
  }
  
  checkAndShowPaywallWarning() {
    if (!this.currentTab) return;
    
    const paywallInfo = this.detectPaywall(this.currentTab.url, this.currentTab.title);
    
    // Remove any existing paywall warning
    const existingWarning = document.querySelector('.paywall-warning');
    if (existingWarning) {
      existingWarning.remove();
    }
    
    if (paywallInfo.isPotentialPaywall) {
      this.showPaywallWarning(paywallInfo);
    }
  }
  
  showPaywallWarning(paywallInfo) {
    const warningElement = document.createElement('div');
    warningElement.className = `paywall-warning paywall-${paywallInfo.confidence}`;
    
    const icon = paywallInfo.confidence === 'high' ? '🔒' : '⚠️';
    const message = paywallInfo.confidence === 'high' 
      ? 'This content may be behind a paywall'
      : 'This content might require a subscription';
    
    warningElement.innerHTML = `
      <div class="paywall-content">
        <span class="paywall-icon">${icon}</span>
        <div class="paywall-text">
          <div class="paywall-message">${message}</div>
          <div class="paywall-reason">${paywallInfo.reason}</div>
        </div>
      </div>
    `;
    
    // Insert warning after page info section
    const pageInfo = document.getElementById('pageInfo');
    pageInfo.parentNode.insertBefore(warningElement, pageInfo.nextSibling);
  }
  
  async loadNotebooks() {
    try {
      const response = await this.sendMessage({ action: 'getNotebooks' });
      
      if (response.success) {
        this.notebooks = response.notebooks;
        this.populateNotebookDropdown();
      } else {
        this.showStatus('warning', 'Could not load notebooks. Please ensure you are logged into NotebookLM.');
        this.populateNotebookDropdown([]);
      }
    } catch (error) {
      console.error('Failed to load notebooks:', error);
      this.populateNotebookDropdown([]);
    }
  }
  
  populateNotebookDropdown() {
    this.notebookSelect.innerHTML = '';
    
    // Add placeholder option
    const placeholder = document.createElement('option');
    placeholder.value = '';
    placeholder.textContent = 'Select a notebook...';
    this.notebookSelect.appendChild(placeholder);
    
    // Add create new notebook option
    const createNewOption = document.createElement('option');
    createNewOption.value = 'CREATE_NEW';
    createNewOption.textContent = '+ Create New Notebook';
    createNewOption.className = 'create-new-option';
    this.notebookSelect.appendChild(createNewOption);
    
    if (this.notebooks.length === 0) {
      return;
    }
    
    // Add separator
    const separator = document.createElement('option');
    separator.disabled = true;
    separator.textContent = '────────────────';
    this.notebookSelect.appendChild(separator);
    
    // Add notebook options
    this.notebooks.forEach(notebook => {
      const option = document.createElement('option');
      option.value = notebook.id;
      option.textContent = `${notebook.emoji || '📔'} ${notebook.name} (${notebook.sourceCount || 0} sources)`;
      this.notebookSelect.appendChild(option);
    });
    
    // Select default notebook if set
    this.selectDefaultNotebook();
  }
  
  async selectDefaultNotebook() {
    try {
      const response = await this.sendMessage({ action: 'getSettings' });
      
      if (response.success && response.settings.defaultNotebook) {
        this.notebookSelect.value = response.settings.defaultNotebook;
        this.handleNotebookSelection();
      }
    } catch (error) {
      console.error('Failed to get default notebook:', error);
    }
  }
  
  handleNotebookSelection() {
    const selectedValue = this.notebookSelect.value;
    
    // Handle create new notebook option
    if (selectedValue === 'CREATE_NEW') {
      this.showCreateNotebookSection();
      this.addToNotebookBtn.disabled = true;
      return;
    }
    
    // Hide create notebook section if it was visible
    this.hideCreateNotebookSection();
    
    const hasSelection = selectedValue !== '';
    this.addToNotebookBtn.disabled = !hasSelection;
    
    // Show/hide open notebook button based on whether we have a last added notebook
    if (this.lastAddedNotebookUrl && hasSelection) {
      this.openNotebookBtn.classList.remove('hidden');
    } else {
      this.openNotebookBtn.classList.add('hidden');
    }
  }
  
  
  async handleAddToNotebook() {
    if (!this.notebookSelect.value) {
      this.showStatus('warning', 'Please select a notebook first');
      return;
    }
    
    if (!this.currentTab) {
      this.showStatus('error', 'Unable to get current page information');
      return;
    }
    
    try {
      this.setButtonLoading(this.addToNotebookBtn, true);
      this.showStatus('loading', 'Adding content to NotebookLM...');
      
      // Create content object from current tab
      const content = {
        title: this.currentTab.title,
        url: this.currentTab.url,
        type: this.detectContentType(this.currentTab.url)
      };
      
      const response = await this.sendMessage({
        action: 'addToNotebook',
        content: content,
        notebookId: this.notebookSelect.value
      });
      
      if (response && response.success) {
        this.showStatus('success', 'Content added to NotebookLM successfully!');
        this.lastAddedNotebookUrl = response.url;
        this.openNotebookBtn.classList.remove('hidden');
        await this.loadRecentSources(); // Refresh recent sources
      } else {
        this.showStatus('error', response?.error || 'Failed to add content to NotebookLM');
      }
    } catch (error) {
      console.error('Failed to add to notebook:', error);
      this.showStatus('error', 'Failed to add content to NotebookLM');
    } finally {
      this.setButtonLoading(this.addToNotebookBtn, false);
    }
  }
  
  handleOpenNotebook() {
    if (this.lastAddedNotebookUrl) {
      chrome.tabs.create({ url: this.lastAddedNotebookUrl });
      window.close();
    } else {
      // Fallback: construct URL from selected notebook ID
      const selectedNotebookId = this.notebookSelect.value;
      if (selectedNotebookId) {
        const notebookUrl = `https://notebooklm.google.com/notebook/${selectedNotebookId}`;
        chrome.tabs.create({ url: notebookUrl });
        window.close();
      }
    }
  }
  
  async loadRecentSources() {
    try {
      const response = await this.sendMessage({ action: 'getRecentSources' });
      
      if (response.success && response.sources.length > 0) {
        this.displayRecentSources(response.sources);
      } else {
        this.recentSources.classList.add('hidden');
      }
    } catch (error) {
      console.error('Failed to load recent sources:', error);
    }
  }
  
  displayRecentSources(sources) {
    this.recentSourcesList.innerHTML = '';
    
    sources.slice(0, 5).forEach(source => {
      const sourceElement = document.createElement('div');
      sourceElement.className = 'recent-source';
      sourceElement.innerHTML = `
        <div class="recent-source-title">${this.truncateText(source.title, 50)}</div>
        <div class="recent-source-meta">
          <span>${new URL(source.url).hostname}</span>
          <span>${this.formatDate(source.addedAt)}</span>
        </div>
      `;
      
      sourceElement.addEventListener('click', () => {
        chrome.tabs.create({ url: source.url });
      });
      
      this.recentSourcesList.appendChild(sourceElement);
    });
    
    this.recentSources.classList.remove('hidden');
    this.recentSources.classList.add('slide-in');
  }
  
  async updateExtensionState() {
    try {
      const response = await this.sendMessage({ action: 'getState' });
      
      if (response) {
        this.currentState = response.state;
        this.updateStatusBadge(response.state);
      }
    } catch (error) {
      console.error('Failed to get extension state:', error);
    }
  }
  
  updateStatusBadge(state) {
    const badgeText = {
      'idle': 'Ready',
      'extracting': 'Extracting...',
      'adding': 'Adding...',
      'success': 'Success',
      'error': 'Error',
      'needs_login': 'Login Required'
    };
    
    this.statusBadge.textContent = badgeText[state] || 'Ready';
    this.statusBadge.className = `status-badge ${state}`;
  }
  
  showStatus(type, message) {
    const icons = {
      'success': '✅',
      'error': '❌',
      'warning': '⚠️',
      'loading': '⏳'
    };
    
    this.statusIcon.textContent = icons[type] || '';
    this.statusText.textContent = message;
    this.statusMessage.className = `status-message status-${type}`;
    this.statusMessage.classList.remove('hidden');
    
    // Auto-hide non-loading messages after 5 seconds
    if (type !== 'loading') {
      setTimeout(() => {
        this.statusMessage.classList.add('hidden');
      }, 5000);
    }
  }
  
  hideStatus() {
    this.statusMessage.classList.add('hidden');
  }
  
  setButtonLoading(button, loading) {
    if (loading) {
      button.disabled = true;
      button.classList.add('loading');
      const icon = button.querySelector('.btn-icon');
      if (icon) {
        icon.innerHTML = '<span class=\"loading-spinner\"></span>';
      }
    } else {
      button.disabled = false;
      button.classList.remove('loading');
      const icon = button.querySelector('.btn-icon');
      if (icon) {
        // Restore original icon based on button
        if (button === this.addToNotebookBtn) {
          icon.textContent = '➕';
        }
      }
      
      // Re-check button state
      this.handleNotebookSelection();
    }
  }
  
  openOptionsPage() {
    chrome.runtime.openOptionsPage();
    window.close();
  }
  
  showHelp() {
    const helpText = `
      NotebookLM Content Adder Help:
      
      1. Navigate to any webpage with content you want to save
      2. Select a NotebookLM notebook from the dropdown (or create a new one)
      3. Click \"Add to NotebookLM\" to save the current page
      4. Click \"Open Notebook\" to view your content in NotebookLM
      
      Supported content types:
      • Articles and blog posts
      • YouTube videos
      • PDF documents
      • Any webpage content
      
      Right-click on any page for quick access via context menu.
    `;
    
    alert(helpText);
  }
  
  handleBackgroundMessage(message, sender, sendResponse) {
    switch (message.action) {
      case 'stateChanged':
        this.updateStatusBadge(message.state);
        break;
    }
  }
  
  // Create notebook methods
  showCreateNotebookSection() {
    this.createNotebookSection.classList.remove('hidden');
    
    // Suggest a name based on current page
    const suggestedName = this.generateNotebookName();
    this.newNotebookName.value = suggestedName;
    this.newNotebookName.select(); // Select all text so user can easily replace it
    this.newNotebookName.focus();
    this.validateNotebookName();
  }
  
  hideCreateNotebookSection() {
    this.createNotebookSection.classList.add('hidden');
    this.newNotebookName.value = '';
  }
  
  generateNotebookName() {
    if (!this.currentTab || !this.currentTab.title) {
      return 'New Notebook';
    }
    
    let title = this.currentTab.title.trim();
    
    // Clean up the title for use as notebook name
    // Remove common website suffixes and prefixes
    title = title.replace(/\s*-\s*.+$/, ''); // Remove " - Website Name" suffix
    title = title.replace(/\s*\|\s*.+$/, ''); // Remove " | Website Name" suffix  
    title = title.replace(/^\([^)]+\)\s*/, ''); // Remove "(1) " prefix from tabs
    title = title.replace(/^New Tab.*/, 'New Notebook'); // Handle new tab case
    
    // Handle specific content types
    const contentType = this.detectContentType(this.currentTab.url);
    switch (contentType) {
      case 'youtube':
        title = title.replace(/\s*-\s*YouTube$/, '');
        break;
      case 'pdf':
        if (title.endsWith('.pdf')) {
          title = title.replace(/\.pdf$/, '');
        }
        break;
      case 'article':
        // Keep article titles as-is after cleanup
        break;
    }
    
    // Limit length and ensure it's not empty
    title = title.substring(0, 50).trim();
    if (!title || title.length < 3) {
      // Fallback: use domain name
      try {
        const domain = new URL(this.currentTab.url).hostname;
        title = domain.replace(/^www\./, '').replace(/\..+$/, '');
        title = title.charAt(0).toUpperCase() + title.slice(1) + ' Research';
      } catch (e) {
        title = 'New Notebook';
      }
    }
    
    return title;
  }
  
  validateNotebookName() {
    const name = this.newNotebookName.value.trim();
    const isValid = name.length > 0 && name.length <= 100;
    this.createNotebookBtn.disabled = !isValid;
    return isValid;
  }
  
  async handleCreateNotebook() {
    if (!this.validateNotebookName()) return;
    
    const notebookName = this.newNotebookName.value.trim();
    
    try {
      this.setButtonLoading(this.createNotebookBtn, true);
      this.showStatus('loading', 'Creating new notebook...');
      
      // Create notebook via service worker
      const response = await this.sendMessage({
        action: 'createNotebook',
        name: notebookName
      });
      
      if (response.success) {
        // Add new notebook to list
        const newNotebook = {
          id: response.notebookId,
          name: notebookName,
          sourceCount: 0,
          emoji: '📔'
        };
        
        this.notebooks.unshift(newNotebook); // Add to beginning
        this.populateNotebookDropdown();
        
        // Select the new notebook
        this.notebookSelect.value = response.notebookId;
        this.hideCreateNotebookSection();
        this.handleNotebookSelection();
        
        this.showStatus('success', `Notebook "${notebookName}" created successfully!`);
        
        // Auto-hide success message after 3 seconds
        setTimeout(() => {
          this.hideStatus();
        }, 3000);
        
      } else {
        this.showStatus('error', response.error || 'Failed to create notebook');
      }
    } catch (error) {
      console.error('Failed to create notebook:', error);
      this.showStatus('error', 'Failed to create notebook. Please try again.');
    } finally {
      this.setButtonLoading(this.createNotebookBtn, false);
    }
  }
  
  handleCancelCreate() {
    this.hideCreateNotebookSection();
    this.notebookSelect.value = '';
    this.handleNotebookSelection();
  }
  
  // Utility methods
  async sendMessage(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve(response);
        }
      });
    });
  }
  
  async sendMessageToTab(message) {
    if (!this.currentTab) return null;
    
    return new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(this.currentTab.id, message, (response) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve(response);
        }
      });
    });
  }
  
  truncateText(text, maxLength) {
    if (!text) return '';
    return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
  }
  
  formatDate(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  }
}

// Initialize popup when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new PopupController();
});

console.log('NotebookLM Content Adder popup script loaded');