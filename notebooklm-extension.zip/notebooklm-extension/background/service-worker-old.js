// NotebookLM Content Adder - Service Worker
// Simplified version for initial loading

console.log('NotebookLM Content Adder service worker starting...');

// Extension states
const EXTENSION_STATES = {
  IDLE: 'idle',
  EXTRACTING: 'extracting',
  ADDING_TO_NOTEBOOK: 'adding',
  SUCCESS: 'success',
  ERROR: 'error',
  NEEDS_LOGIN: 'needs_login'
};

// Global state
let currentState = EXTENSION_STATES.IDLE;

// Installation handler
chrome.runtime.onInstalled.addListener((details) => {
  console.log('NotebookLM Content Adder installed:', details.reason);
  
  // Initialize default settings
  initializeDefaultSettings();
  
  // Set up context menu
  setupContextMenu();
});

// Initialize default settings
async function initializeDefaultSettings() {
  try {
    const result = await chrome.storage.sync.get(['userSettings']);
    
    if (!result.userSettings) {
      const defaultSettings = {
        defaultNotebook: '',
        autoExtractContent: true,
        excludeNavigation: true,
        excludeAds: true,
        enableSmartExtraction: true,
        preferMarkdown: false,
        autoOpenNotebook: false,
        showExtractionPreview: true
      };
      
      await chrome.storage.sync.set({ 
        userSettings: defaultSettings,
        notebooks: [],
        recentSources: []
      });
      
      console.log('Default settings initialized');
    }
  } catch (error) {
    console.error('Failed to initialize settings:', error);
  }
}

// Set up context menu
function setupContextMenu() {
  try {
    chrome.contextMenus.removeAll(() => {
      chrome.contextMenus.create({
        id: 'add-to-notebooklm',
        title: 'Add to NotebookLM',
        contexts: ['page', 'selection', 'link'],
        documentUrlPatterns: ['http://*/*', 'https://*/*']
      });
      
      chrome.contextMenus.create({
        id: 'add-selection-to-notebooklm',
        title: 'Add selected text to NotebookLM',
        contexts: ['selection'],
        documentUrlPatterns: ['http://*/*', 'https://*/*']
      });
    });
  } catch (error) {
    console.error('Failed to setup context menu:', error);
  }
}

// Context menu click handler
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'add-to-notebooklm' || info.menuItemId === 'add-selection-to-notebooklm') {
    handleContextMenuClick(info, tab);
  }
});

// Handle context menu clicks
async function handleContextMenuClick(info, tab) {
  try {
    // Extract content from current page
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractPageContent,
      args: [{ selection: info.selectionText }]
    });
    
    if (results && results[0]) {
      const content = results[0].result;
      console.log('Content extracted via context menu:', content.type);
      
      // For now, just log the content - full automation will be added later
      chrome.action.openPopup();
    }
  } catch (error) {
    console.error('Context menu extraction failed:', error);
  }
}

// Message handler
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  handleMessage(request, sender, sendResponse);
  return true; // Keep message channel open
});

// Main message handler
async function handleMessage(request, sender, sendResponse) {
  try {
    switch (request.action) {
      case 'getState':
        sendResponse({ state: currentState });
        break;
        
      case 'extractContent':
        await handleExtractContent(request, sender, sendResponse);
        break;
        
      case 'getSettings':
        await handleGetSettings(sendResponse);
        break;
        
      case 'saveSettings':
        await handleSaveSettings(request.settings, sendResponse);
        break;
        
      case 'getNotebooks':
        await handleGetNotebooks(sendResponse);
        break;
        
      case 'addToNotebook':
        await handleAddToNotebook(request, sendResponse);
        break;
        
      case 'getRecentSources':
        await handleGetRecentSources(sendResponse);
        break;
        
      default:
        sendResponse({ error: 'Unknown action: ' + request.action });
    }
  } catch (error) {
    console.error('Error handling message:', error);
    sendResponse({ error: error.message });
  }
}

// Handle content extraction
async function handleExtractContent(request, sender, sendResponse) {
  currentState = EXTENSION_STATES.EXTRACTING;
  
  try {
    const tab = sender.tab || (await getCurrentTab());
    
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractPageContent,
      args: [request.options || {}]
    });
    
    if (results && results[0]) {
      const extractedContent = results[0].result;
      currentState = EXTENSION_STATES.IDLE;
      sendResponse({ success: true, content: extractedContent });
    } else {
      throw new Error('Failed to extract content');
    }
  } catch (error) {
    currentState = EXTENSION_STATES.ERROR;
    sendResponse({ success: false, error: error.message });
  }
}

// Settings handlers
async function handleGetSettings(sendResponse) {
  try {
    const result = await chrome.storage.sync.get(['userSettings']);
    sendResponse({ success: true, settings: result.userSettings || {} });
  } catch (error) {
    sendResponse({ success: false, error: error.message });
  }
}

async function handleSaveSettings(settings, sendResponse) {
  try {
    await chrome.storage.sync.set({ userSettings: settings });
    sendResponse({ success: true });
  } catch (error) {
    sendResponse({ success: false, error: error.message });
  }
}

// Utility functions
async function getCurrentTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0];
}

// Handle getting notebooks from NotebookLM
async function handleGetNotebooks(sendResponse) {
  try {
    console.log('Starting notebook fetching process...');
    currentState = EXTENSION_STATES.EXTRACTING;
    
    // Find or create NotebookLM tab
    const notebookLMTab = await findOrCreateNotebookLMTab();
    
    if (!notebookLMTab) {
      throw new Error('Could not open NotebookLM. Please ensure you have access to NotebookLM.');
    }
    
    // Wait for tab to load
    await waitForTabLoad(notebookLMTab.id);
    
    // Inject the NotebookLM API script
    await chrome.scripting.executeScript({
      target: { tabId: notebookLMTab.id },
      files: ['utils/notebooklm-api.js']
    });
    
    // Execute the notebook fetching
    const results = await chrome.scripting.executeScript({
      target: { tabId: notebookLMTab.id },
      func: async () => {
        try {
          // Create NotebookLM API instance
          const api = new NotebookLMAPI();
          
          // Check if we're authenticated
          if (!api.isNotebookLMPage()) {
            throw new Error('Not on NotebookLM page');
          }
          
          await api.ensureAuthenticated();
          
          // Get notebooks
          const notebooks = await api.getNotebooks();
          return { success: true, notebooks };
        } catch (error) {
          console.error('Error fetching notebooks:', error);
          return { success: false, error: error.message };
        }
      }
    });
    
    currentState = EXTENSION_STATES.IDLE;
    
    if (results && results[0] && results[0].result) {
      const result = results[0].result;
      console.log('Notebooks fetched:', result);
      sendResponse(result);
    } else {
      throw new Error('Failed to fetch notebooks from NotebookLM');
    }
    
  } catch (error) {
    console.error('Failed to get notebooks:', error);
    currentState = EXTENSION_STATES.ERROR;
    sendResponse({ 
      success: false, 
      error: error.message,
      notebooks: []
    });
  }
}

// Handle adding content to NotebookLM
async function handleAddToNotebook(request, sendResponse) {
  try {
    console.log('Starting add to notebook process...');
    currentState = EXTENSION_STATES.ADDING_TO_NOTEBOOK;
    
    const { content, notebookId } = request;
    
    if (!content) {
      throw new Error('No content provided');
    }
    
    // Find or create NotebookLM tab
    const notebookLMTab = await findOrCreateNotebookLMTab();
    
    if (!notebookLMTab) {
      throw new Error('Could not open NotebookLM');
    }
    
    // Wait for tab to load
    await waitForTabLoad(notebookLMTab.id);
    
    // Inject the NotebookLM API script
    await chrome.scripting.executeScript({
      target: { tabId: notebookLMTab.id },
      files: ['utils/notebooklm-api.js']
    });
    
    // Execute the content addition
    const results = await chrome.scripting.executeScript({
      target: { tabId: notebookLMTab.id },
      func: async (contentData, targetNotebookId) => {
        try {
          const api = new NotebookLMAPI();
          const result = await api.addContentToNotebook(contentData, targetNotebookId);
          return result;
        } catch (error) {
          console.error('Error adding to notebook:', error);
          return { success: false, error: error.message };
        }
      },
      args: [content, notebookId]
    });
    
    currentState = EXTENSION_STATES.SUCCESS;
    
    if (results && results[0] && results[0].result) {
      const result = results[0].result;
      console.log('Content added:', result);
      
      // Store recent source
      if (result.success) {
        await storeRecentSource({
          title: content.title || 'Untitled',
          url: content.url || '',
          type: content.type || 'webpage',
          addedAt: Date.now(),
          notebookId: notebookId
        });
      }
      
      sendResponse(result);
    } else {
      throw new Error('Failed to add content to NotebookLM');
    }
    
  } catch (error) {
    console.error('Failed to add to notebook:', error);
    currentState = EXTENSION_STATES.ERROR;
    sendResponse({ 
      success: false, 
      error: error.message 
    });
  }
}

// Find existing NotebookLM tab or create new one
async function findOrCreateNotebookLMTab() {
  try {
    // First, try to find existing NotebookLM tab
    const tabs = await chrome.tabs.query({ url: "https://notebooklm.google.com/*" });
    
    if (tabs.length > 0) {
      // Found existing tab, activate it
      const tab = tabs[0];
      await chrome.tabs.update(tab.id, { active: true });
      await chrome.windows.update(tab.windowId, { focused: true });
      return tab;
    }
    
    // No existing tab, create new one
    const newTab = await chrome.tabs.create({
      url: 'https://notebooklm.google.com/notebooks',
      active: true
    });
    
    return newTab;
  } catch (error) {
    console.error('Error finding/creating NotebookLM tab:', error);
    return null;
  }
}

// Wait for tab to finish loading
async function waitForTabLoad(tabId, timeout = 30000) {
  return new Promise((resolve, reject) => {
    const startTime = Date.now();
    
    const checkTab = async () => {
      try {
        const tab = await chrome.tabs.get(tabId);
        
        if (tab.status === 'complete') {
          // Give it a bit more time for JavaScript to load
          setTimeout(resolve, 2000);
          return;
        }
        
        if (Date.now() - startTime > timeout) {
          reject(new Error('Tab load timeout'));
          return;
        }
        
        // Check again in 500ms
        setTimeout(checkTab, 500);
      } catch (error) {
        reject(error);
      }
    };
    
    checkTab();
  });
}

// Store recent source for display in popup
async function storeRecentSource(source) {
  try {
    const result = await chrome.storage.local.get(['recentSources']);
    const recentSources = result.recentSources || [];
    
    // Add new source to beginning
    recentSources.unshift(source);
    
    // Keep only last 10 sources
    if (recentSources.length > 10) {
      recentSources.splice(10);
    }
    
    await chrome.storage.local.set({ recentSources });
  } catch (error) {
    console.error('Failed to store recent source:', error);
  }
}

// Handle getting recent sources
async function handleGetRecentSources(sendResponse) {
  try {
    const result = await chrome.storage.local.get(['recentSources']);
    sendResponse({ 
      success: true, 
      sources: result.recentSources || [] 
    });
  } catch (error) {
    console.error('Failed to get recent sources:', error);
    sendResponse({ 
      success: false, 
      error: error.message, 
      sources: [] 
    });
  }
}

// Content extraction function (injected into pages)
function extractPageContent(options = {}) {
  const content = {
    url: window.location.href,
    title: document.title,
    domain: window.location.hostname,
    extractedAt: Date.now(),
    type: 'webpage'
  };
  
  // If selection provided, use that
  if (options.selection) {
    content.text = options.selection;
    content.type = 'selection';
    return content;
  }
  
  // Detect content type
  if (window.location.hostname === 'www.youtube.com' && window.location.pathname.includes('/watch')) {
    content.type = 'youtube';
    content.videoId = new URL(window.location.href).searchParams.get('v');
  } else if (window.location.href.includes('.pdf')) {
    content.type = 'pdf';
  } else {
    content.type = 'article';
  }
  
  // Extract main content
  const mainContent = document.querySelector('main, article, .content, .post, .entry') || document.body;
  
  if (mainContent) {
    const clone = mainContent.cloneNode(true);
    
    // Remove unwanted elements
    const unwanted = clone.querySelectorAll('script, style, nav, header, footer, .navigation, .sidebar, .ad, .ads');
    unwanted.forEach(el => el.remove());
    
    content.text = clone.textContent.trim();
    content.html = clone.innerHTML;
  }
  
  // Extract metadata
  const description = document.querySelector('meta[name="description"]');
  if (description) content.description = description.content;
  
  const author = document.querySelector('meta[name="author"]');
  if (author) content.author = author.content;
  
  return content;
}

console.log('NotebookLM Content Adder service worker loaded successfully');