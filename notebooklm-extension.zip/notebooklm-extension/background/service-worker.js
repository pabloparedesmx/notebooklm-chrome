// Service worker for NotebookLM Extension
// Based on working extension implementation

// Extension states
const EXTENSION_STATES = {
  IDLE: 'idle',
  EXTRACTING: 'extracting',
  ADDING_TO_NOTEBOOK: 'adding_to_notebook',
  SUCCESS: 'success',
  ERROR: 'error'
};

let currentState = EXTENSION_STATES.IDLE;

// Utility functions
function delay(ms = 0) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function extractToken(tokenName, htmlContent) {
  const regex = new RegExp(`"${tokenName}":"([^"]+)"`);
  const match = regex.exec(htmlContent);
  return match ? match[1] : null;
}

// Get authentication tokens from NotebookLM
async function getNotebookLMTokens() {
  try {
    const response = await fetch('https://notebooklm.google.com/', {
      redirect: 'error'
    });
    
    if (!response.ok) {
      throw new Error('Please authorize NotebookLM to continue');
    }
    
    const html = await response.text();
    const cfb2h = extractToken('cfb2h', html);
    const SNlM0e = extractToken('SNlM0e', html);
    
    if (!cfb2h || !SNlM0e) {
      throw new Error('Please authorize NotebookLM to continue');
    }
    
    return { cfb2h, SNlM0e };
  } catch (error) {
    throw new Error('Please authorize NotebookLM to continue');
  }
}

// List all notebooks
async function listNotebooks() {
  try {
    const { cfb2h, SNlM0e } = await getNotebookLMTokens();
    
    const url = new URL('https://notebooklm.google.com/_/LabsTailwindUi/data/batchexecute');
    const reqId = (Math.floor(Math.random() * 900000) + 100000).toString();
    const rpcId = 'wXbhsf';
    
    const params = new URLSearchParams();
    params.append('rpcids', rpcId);
    params.append('source-path', '/');
    params.append('bl', cfb2h);
    params.append('_reqid', reqId);
    params.append('rt', 'c');
    
    const body = new URLSearchParams({
      'f.req': JSON.stringify([[[rpcId, JSON.stringify([null, 1, null, [2]]), null, 'generic']]]),
      'at': SNlM0e
    });
    
    const response = await fetch(`${url}?${params.toString()}`, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      method: 'POST',
      body: body.toString()
    });
    
    if (!response.ok) {
      throw new Error('Error getting notebook list');
    }
    
    const blob = await response.blob();
    const text = await blob.text();
    const data = JSON.parse(JSON.parse(text.split('\n')[3])[0][2])[0];
    
    if (!data) {
      return { success: true, notebooks: [] };
    }
    
    const notebooks = data
      .filter(notebook => {
        if (!notebook || notebook.length < 6) return false;
        const status = notebook[5];
        return !(Array.isArray(status) && status.length > 0 && status[0] === 3);
      })
      .map(notebook => {
        if (notebook.length < 3) return {};
        const [name, sources, id, emoji] = notebook;
        return {
          id: id,
          name: name ? name.trim() : 'Untitled notebook',
          sourceCount: sources ? sources.length : 0,
          emoji: emoji || '📔'
        };
      });
    
    return { success: true, notebooks };
  } catch (error) {
    console.error('Failed to list notebooks:', error);
    return { success: false, error: error.message, notebooks: [] };
  }
}

// Create a new notebook
async function createNotebook(title) {
  try {
    const { cfb2h, SNlM0e } = await getNotebookLMTokens();
    
    const url = new URL('https://notebooklm.google.com/_/LabsTailwindUi/data/batchexecute');
    const reqId = (Math.floor(Math.random() * 900000) + 100000).toString();
    const rpcId = 'CCqFvf';
    
    const params = new URLSearchParams();
    params.append('rpcids', rpcId);
    params.append('source-path', '/');
    params.append('bl', cfb2h);
    params.append('_reqid', reqId);
    params.append('rt', 'c');
    
    const body = new URLSearchParams({
      'f.req': JSON.stringify([[[rpcId, JSON.stringify([title]), null, 'generic']]]),
      'at': SNlM0e
    });
    
    const response = await fetch(`${url}?${params.toString()}`, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      method: 'POST',
      body: body.toString()
    });
    
    if (!response.ok) {
      throw new Error('Error creating notebook');
    }
    
    const blob = await response.blob();
    const text = await blob.text();
    
    // Extract notebook ID from response
    const uuidMatch = text.match(/\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b/g);
    return uuidMatch ? uuidMatch[0] : null;
  } catch (error) {
    console.error('Failed to create notebook:', error);
    throw error;
  }
}

// Get source limit for notebook
async function getSourceLimit(cfb2h, SNlM0e) {
  try {
    const url = new URL('https://notebooklm.google.com/_/LabsTailwindUi/data/batchexecute');
    const reqId = (Math.floor(Math.random() * 900000) + 100000).toString();
    const rpcId = 'ozz5Z';
    
    const params = new URLSearchParams();
    params.append('rpcids', rpcId);
    params.append('source-path', '/');
    params.append('bl', cfb2h);
    params.append('_reqid', reqId);
    params.append('rt', 'c');
    
    const body = new URLSearchParams({
      'f.req': JSON.stringify([[[rpcId, '[[[[null,"1",627],null,1]]]', null, 'generic']]]),
      'at': SNlM0e
    });
    
    const response = await fetch(`${url}?${params.toString()}`, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      method: 'POST',
      body: body.toString()
    });
    
    if (!response.ok) {
      return 300; // Default limit
    }
    
    const blob = await response.blob();
    const text = await blob.text();
    
    // Check if user has plus features
    return text.indexOf('notebooklm_plus_icon') === -1 ? 300 : 50;
  } catch (error) {
    return 300; // Default limit
  }
}

// Add sources to notebook
async function addSourcesToNotebook(cfb2h, SNlM0e, notebookId, urls) {
  try {
    const url = new URL('https://notebooklm.google.com/_/LabsTailwindUi/data/batchexecute');
    const reqId = (Math.floor(Math.random() * 900000) + 100000).toString();
    const rpcId = 'izAoDd';
    
    const params = new URLSearchParams();
    params.append('rpcids', rpcId);
    params.append('source-path', `/notebook/${notebookId}`);
    params.append('bl', cfb2h);
    params.append('_reqid', reqId);
    params.append('rt', 'c');
    
    // Prepare sources array
    const sources = [];
    for (const url of urls) {
      if (url.includes('youtube.com')) {
        sources.push([null, null, null, null, null, null, null, [url]]);
      } else {
        sources.push([null, null, [url]]);
      }
    }
    
    const body = new URLSearchParams({
      'f.req': JSON.stringify([[[rpcId, JSON.stringify([sources, notebookId]), null, 'generic']]]),
      'at': SNlM0e
    });
    
    const response = await fetch(`${url}?${params.toString()}`, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      method: 'POST',
      body: body.toString()
    });
    
    return response.ok;
  } catch (error) {
    console.error('Failed to add sources:', error);
    return false;
  }
}

// Check if sources are processed
async function checkSourcesProcessed(cfb2h, SNlM0e, notebookId) {
  try {
    const url = new URL('https://notebooklm.google.com/_/LabsTailwindUi/data/batchexecute');
    const reqId = (Math.floor(Math.random() * 900000) + 100000).toString();
    const rpcId = 'rLM1Ne';
    
    const params = new URLSearchParams();
    params.append('rpcids', rpcId);
    params.append('source-path', `/notebook/${notebookId}`);
    params.append('bl', cfb2h);
    params.append('_reqid', reqId);
    params.append('rt', 'c');
    
    const body = new URLSearchParams({
      'f.req': JSON.stringify([[[rpcId, JSON.stringify([notebookId, null, [2]]), null, 'generic']]]),
      'at': SNlM0e
    });
    
    const response = await fetch(`${url}?${params.toString()}`, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      method: 'POST',
      body: body.toString()
    });
    
    if (!response.ok) {
      return false;
    }
    
    const blob = await response.blob();
    const text = await blob.text();
    
    // Check if processing is complete
    return text.indexOf(`null,\\"${notebookId}`) === -1;
  } catch (error) {
    return false;
  }
}

// Handle creating a new notebook
async function handleCreateNotebook(name) {
  try {
    const notebookId = await createNotebook(name);
    if (notebookId) {
      return {
        success: true,
        notebookId: notebookId
      };
    } else {
      return {
        success: false,
        error: 'Failed to create notebook'
      };
    }
  } catch (error) {
    console.error('Failed to create notebook:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

// Main function to save content to NotebookLM
async function saveToNotebookLM(title, urls, currentURL, notebookID) {
  try {
    chrome.storage.local.set({ [currentURL]: { label: 'Creating Notebook...' } });
    
    const { cfb2h, SNlM0e } = await getNotebookLMTokens();
    
    // Use existing notebook or create new one
    let notebookId = notebookID;
    if (!notebookId) {
      notebookId = await createNotebook(title);
      if (!notebookId) {
        throw new Error('Failed to create notebook');
      }
    }
    
    // Get source limit
    const limit = await getSourceLimit(cfb2h, SNlM0e);
    
    // Process URLs in batches according to limit
    chrome.storage.local.set({ [currentURL]: { label: 'Adding sources...' } });
    const urlBatch = urls.slice(0, limit);
    
    // Add sources
    const success = await addSourcesToNotebook(cfb2h, SNlM0e, notebookId, urlBatch);
    if (!success) {
      throw new Error('Failed to add sources');
    }
    
    // Wait for processing to complete
    let processed = false;
    while (!processed) {
      await delay(1000);
      processed = await checkSourcesProcessed(cfb2h, SNlM0e, notebookId);
    }
    
    // Clean up storage
    await chrome.storage.local.remove(currentURL);
    
    return {
      success: true,
      url: `https://notebooklm.google.com/notebook/${notebookId}`
    };
  } catch (error) {
    console.error('Failed to save to NotebookLM:', error);
    await chrome.storage.local.remove(currentURL);
    return {
      success: false,
      error: error.message
    };
  }
}

// Message handler
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  (async () => {
    try {
      switch (request.action) {
        case 'getSettings':
          const settings = await chrome.storage.sync.get(['autoDetect', 'selectedNotebook', 'apiKey']);
          sendResponse({ success: true, settings });
          break;
          
        case 'saveSettings':
          await chrome.storage.sync.set(request.settings);
          sendResponse({ success: true });
          break;
          
        case 'getNotebooks':
          const result = await listNotebooks();
          sendResponse(result);
          break;
          
        case 'createNotebook':
          const createResult = await handleCreateNotebook(request.name);
          sendResponse(createResult);
          break;
          
        case 'addToNotebook':
          const { content, notebookId } = request;
          const urls = content.url ? [content.url] : [];
          const title = content.title || 'Untitled';
          const saveResult = await saveToNotebookLM(title, urls, content.url, notebookId);
          sendResponse(saveResult);
          break;
          
        case 'getRecentSources':
          const recentData = await chrome.storage.local.get(['recentSources']);
          sendResponse({ 
            success: true, 
            sources: recentData.recentSources || [] 
          });
          break;
          
        default:
          sendResponse({ error: 'Unknown action: ' + request.action });
      }
    } catch (error) {
      console.error('Error handling message:', error);
      sendResponse({ error: error.message });
    }
  })();
  
  return true; // Keep message channel open for async response
});

console.log('NotebookLM Extension service worker loaded');