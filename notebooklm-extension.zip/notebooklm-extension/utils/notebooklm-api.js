// NotebookLM API Utilities
// Handles automation and interaction with NotebookLM interface

class NotebookLMAPI {
  constructor() {
    this.selectors = {
      // Authentication
      loginButton: '[data-testid*="sign-in"], [aria-label*="Sign in"], button:contains("Sign in")',
      
      // Navigation
      notebooksGrid: '[data-testid*="notebook"], .notebook-grid, [class*="notebook-list"]',
      notebookCard: '.notebook-card, [data-testid*="notebook-card"]',
      createNotebookButton: '[data-testid*="create"], button:contains("Create"), button[aria-label*="Create"]',
      
      // Sources
      addSourceButton: '[data-testid*="add"], button[aria-label*="Add"], button:contains("Add source")',
      sourceModal: '[role="dialog"], .modal, [data-testid*="modal"]',
      sourceTypeButtons: '[data-testid*="source-type"], .source-type-button',
      
      // Input fields
      urlInput: 'input[type="url"], input[placeholder*="URL"], input[placeholder*="url"]',
      textInput: 'textarea, [contenteditable="true"], input[type="text"]',
      titleInput: 'input[placeholder*="title"], input[placeholder*="Title"]',
      
      // Actions
      submitButton: 'button[type="submit"], button:contains("Add"), button:contains("Submit"), button:contains("Save")',
      cancelButton: 'button:contains("Cancel"), button[aria-label*="Cancel"]',
      
      // Status indicators
      successMessage: '[data-testid*="success"], .success-message, [class*="success"]',
      errorMessage: '[data-testid*="error"], .error-message, [class*="error"]',
      loadingIndicator: '[data-testid*="loading"], .loading, .spinner'
    };
    
    this.timeouts = {
      short: 2000,
      medium: 5000,
      long: 10000,
      veryLong: 20000
    };
  }
  
  // Main method to add content to NotebookLM
  async addContentToNotebook(content, notebookId = null) {
    try {
      console.log('Starting NotebookLM automation for content:', content.type);
      
      // Step 1: Verify we're on NotebookLM
      if (!this.isNotebookLMPage()) {
        throw new Error('Not on NotebookLM page');
      }
      
      // Step 2: Check authentication
      await this.ensureAuthenticated();
      
      // Step 3: Navigate to specific notebook or stay on current page
      if (notebookId) {
        await this.navigateToNotebook(notebookId);
      }
      
      // Step 4: Open add source dialog
      await this.openAddSourceDialog();
      
      // Step 5: Add the content based on type
      await this.addContentByType(content);
      
      // Step 6: Submit and verify
      const result = await this.submitAndVerify();
      
      console.log('Content added successfully to NotebookLM');
      return { success: true, result };
      
    } catch (error) {
      console.error('NotebookLM automation failed:', error);
      return { success: false, error: error.message };
    }
  }
  
  // Check if we're on a NotebookLM page
  isNotebookLMPage() {
    return window.location.hostname === 'notebooklm.google.com';
  }
  
  // Ensure user is authenticated
  async ensureAuthenticated() {
    // Check for sign-in button
    const loginButton = document.querySelector(this.selectors.loginButton);
    
    if (loginButton && loginButton.offsetParent !== null) {
      throw new Error('Please sign in to NotebookLM first. Click the extension when you are logged in.');
    }
    
    // Check for Google account picker or other auth indicators
    const accountPicker = document.querySelector('[data-account-picker], .account-picker, [role="listbox"]');
    if (accountPicker && accountPicker.offsetParent !== null) {
      throw new Error('Please complete Google account selection to access NotebookLM');
    }
    
    // Check if we're on an error page
    if (document.title.includes('Error') || document.body.textContent.includes('Access denied')) {
      throw new Error('Access denied to NotebookLM. Please check your account permissions.');
    }
    
    // Wait a moment for page to fully load
    await this.wait(this.timeouts.short);
    
    // Additional check - look for NotebookLM-specific elements
    const notebookElements = document.querySelectorAll('[data-testid*="notebook"], .notebook, [class*="notebook"]');
    if (notebookElements.length === 0 && !document.querySelector('.loading, [data-testid*="loading"]')) {
      // Give it more time to load
      await this.wait(this.timeouts.medium);
      
      const notebookElementsRetry = document.querySelectorAll('[data-testid*="notebook"], .notebook, [class*="notebook"]');
      if (notebookElementsRetry.length === 0) {
        throw new Error('NotebookLM interface not detected. Please ensure you are logged in and have access to NotebookLM.');
      }
    }
  }
  
  // Navigate to specific notebook
  async navigateToNotebook(notebookId) {
    const currentUrl = window.location.href;
    const targetUrl = `https://notebooklm.google.com/notebook/${notebookId}`;
    
    if (currentUrl !== targetUrl) {
      window.location.href = targetUrl;
      
      // Wait for navigation to complete
      await this.waitForPageLoad();
    }
  }
  
  // Open the add source dialog
  async openAddSourceDialog() {
    const addButton = await this.waitForElement(this.selectors.addSourceButton, this.timeouts.medium);
    
    if (!addButton) {
      throw new Error('Could not find Add Source button');
    }
    
    // Click the add source button
    addButton.click();
    
    // Wait for modal to appear
    const modal = await this.waitForElement(this.selectors.sourceModal, this.timeouts.medium);
    
    if (!modal) {
      throw new Error('Add source dialog did not open');
    }
    
    console.log('Add source dialog opened');
  }
  
  // Add content based on its type
  async addContentByType(content) {
    switch (content.type) {
      case 'youtube':
      case 'pdf':
        await this.addUrlContent(content);
        break;
        
      case 'article':
      case 'webpage':
        await this.addTextContent(content);
        break;
        
      case 'selection':
        await this.addTextContent(content);
        break;
        
      default:
        await this.addTextContent(content);
    }
  }
  
  // Add URL-based content (YouTube, PDF)
  async addUrlContent(content) {
    console.log('Adding URL content:', content.url);
    
    // Look for URL source type button first
    const urlTypeButton = document.querySelector('[data-testid*="url"], button:contains("URL"), button:contains("Link")');
    if (urlTypeButton) {
      urlTypeButton.click();
      await this.wait(1000);
    }
    
    // Find URL input field
    const urlInput = await this.waitForElement(this.selectors.urlInput, this.timeouts.short);
    
    if (urlInput) {
      // Clear and enter URL
      urlInput.value = '';
      urlInput.focus();
      await this.typeText(urlInput, content.url);
      
      // Trigger input events
      urlInput.dispatchEvent(new Event('input', { bubbles: true }));
      urlInput.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
      // Fallback to text input
      await this.addTextContent(content);
    }
  }
  
  // Add text-based content
  async addTextContent(content) {
    console.log('Adding text content, length:', content.text?.length || 0);
    
    // Look for text source type button
    const textTypeButton = document.querySelector('[data-testid*="text"], button:contains("Text"), button:contains("Paste")');
    if (textTypeButton) {
      textTypeButton.click();
      await this.wait(1000);
    }
    
    // Find text input area
    const textInput = await this.waitForElement(this.selectors.textInput, this.timeouts.short);
    
    if (!textInput) {
      throw new Error('Could not find text input field');
    }
    
    // Prepare content text
    let contentText = '';
    
    if (content.type === 'article' || content.type === 'webpage') {
      contentText = this.formatArticleContent(content);
    } else if (content.type === 'selection') {
      contentText = content.text || '';
    } else {
      contentText = content.text || content.description || content.url || '';
    }
    
    // Truncate if too long
    if (contentText.length > 50000) {
      contentText = contentText.substring(0, 50000) + '\n\n[Content truncated]';
    }
    
    // Clear and enter content
    if (textInput.tagName.toLowerCase() === 'textarea') {
      textInput.value = contentText;
    } else {
      textInput.textContent = contentText;
      textInput.innerText = contentText;
    }
    
    // Trigger events
    textInput.focus();
    textInput.dispatchEvent(new Event('input', { bubbles: true }));
    textInput.dispatchEvent(new Event('change', { bubbles: true }));
  }
  
  // Format article content for NotebookLM
  formatArticleContent(content) {
    let formatted = '';
    
    // Add title
    if (content.title) {
      formatted += `# ${content.title}\n\n`;
    }
    
    // Add source URL
    if (content.url) {
      formatted += `Source: ${content.url}\n\n`;
    }
    
    // Add metadata
    if (content.author) {
      formatted += `Author: ${content.author}\n`;
    }
    
    if (content.publishedAt) {
      formatted += `Published: ${content.publishedAt}\n`;
    }
    
    if (content.readingTime) {
      formatted += `Reading time: ${content.readingTime} min\n`;
    }
    
    if (content.author || content.publishedAt || content.readingTime) {
      formatted += '\n';
    }
    
    // Add description if available
    if (content.description && content.description !== content.title) {
      formatted += `${content.description}\n\n`;
    }
    
    // Add main content
    if (content.markdown) {
      formatted += content.markdown;
    } else if (content.text) {
      formatted += content.text;
    }
    
    return formatted;
  }
  
  // Submit the form and verify success
  async submitAndVerify() {
    console.log('Submitting content to NotebookLM');
    
    // Find and click submit button
    const submitButton = await this.waitForElement(this.selectors.submitButton, this.timeouts.short);
    
    if (!submitButton) {
      throw new Error('Could not find submit button');
    }
    
    submitButton.click();
    
    // Wait for submission to complete
    await this.wait(this.timeouts.medium);
    
    // Check for success or error messages
    const successMessage = document.querySelector(this.selectors.successMessage);
    const errorMessage = document.querySelector(this.selectors.errorMessage);
    
    if (errorMessage && errorMessage.offsetParent !== null) {
      throw new Error(`NotebookLM error: ${errorMessage.textContent}`);
    }
    
    // Wait a bit more for the UI to update
    await this.wait(this.timeouts.short);
    
    return {
      success: true,
      timestamp: Date.now()
    };
  }
  
  // Get list of available notebooks
  async getNotebooks() {
    try {
      console.log('Starting notebook detection...');
      
      // Navigate to notebooks list if not already there
      if (!window.location.pathname.includes('/notebooks')) {
        console.log('Navigating to notebooks page...');
        window.location.href = 'https://notebooklm.google.com/notebooks';
        await this.waitForPageLoad();
      }
      
      // Wait for page to stabilize
      await this.wait(this.timeouts.short);
      
      // Try multiple selectors for individual notebook cards
      const possibleCardSelectors = [
        '.notebook-card',
        '[data-testid*="notebook-card"]',
        '[data-testid*="notebook"]',
        '[class*="card"]',
        '[role="button"]',
        'a[href*="/notebook/"]',
        'div[style*="cursor: pointer"]'
      ];
      
      let notebookCards = [];
      for (const selector of possibleCardSelectors) {
        notebookCards = document.querySelectorAll(selector);
        if (notebookCards.length > 0) {
          console.log(`Found ${notebookCards.length} notebook cards with selector: ${selector}`);
          break;
        }
      }
      
      const notebooks = [];
      
      notebookCards.forEach((card, index) => {
        // Try multiple selectors for title
        const titleSelectors = [
          'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
          '.title',
          '[data-testid*="title"]',
          '[class*="title"]',
          'span',
          'div'
        ];
        
        let titleElement = null;
        for (const selector of titleSelectors) {
          titleElement = card.querySelector(selector);
          if (titleElement && titleElement.textContent.trim()) {
            break;
          }
        }
        
        if (titleElement) {
          const title = titleElement.textContent.trim();
          
          // Skip if title is too generic or empty
          if (title && title.length > 0 && !['New', 'Untitled', 'Loading', '...'].includes(title)) {
            const notebook = {
              id: this.extractNotebookId(card) || `notebook-${Date.now()}-${index}`,
              name: title,
              sourceCount: this.extractSourceCount(card),
              lastAccessed: Date.now()
            };
            
            notebooks.push(notebook);
            console.log(`Found notebook: ${notebook.name}`);
          }
        }
      });
      
      // If we still don't have notebooks, try a more aggressive approach
      if (notebooks.length === 0) {
        console.log('No notebooks found with standard selectors, trying text-based approach...');
        
        // Look for any clickable elements that might be notebooks
        const clickableElements = document.querySelectorAll('a, button, [role="button"], [onclick], [style*="cursor: pointer"]');
        
        clickableElements.forEach((element, index) => {
          const text = element.textContent.trim();
          const href = element.href || '';
          
          // Check if this looks like a notebook
          if ((href.includes('/notebook/') || text.length > 3) && 
              !text.includes('Sign') && 
              !text.includes('Create') && 
              !text.includes('Help') &&
              text.length < 100) {
            
            notebooks.push({
              id: this.extractNotebookId(element) || `text-notebook-${Date.now()}-${index}`,
              name: text || `Notebook ${index + 1}`,
              sourceCount: 0,
              lastAccessed: Date.now()
            });
          }
        });
      }
      
      console.log(`Final result: Found ${notebooks.length} notebooks`);
      return notebooks;
      
    } catch (error) {
      console.error('Failed to get notebooks:', error);
      throw error;
    }
  }
  
  // Extract notebook ID from card element
  extractNotebookId(cardElement) {
    // Try to find ID in various places
    const link = cardElement.querySelector('a[href*="/notebook/"]');
    if (link) {
      const match = link.href.match(/\/notebook\/([^?\/]+)/);
      if (match) return match[1];
    }
    
    // Check data attributes
    if (cardElement.dataset.notebookId) {
      return cardElement.dataset.notebookId;
    }
    
    return null;
  }
  
  // Extract source count from element
  extractSourceCount(element) {
    if (!element) return 0;
    
    const text = element.textContent;
    const match = text.match(/(\d+)/);
    return match ? parseInt(match[1]) : 0;
  }
  
  // Utility methods
  
  async wait(milliseconds) {
    return new Promise(resolve => setTimeout(resolve, milliseconds));
  }
  
  async waitForElement(selector, timeout = 5000) {
    const startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
      const element = document.querySelector(selector);
      if (element && element.offsetParent !== null) {
        return element;
      }
      await this.wait(100);
    }
    
    return null;
  }
  
  async waitForPageLoad() {
    return new Promise((resolve) => {
      if (document.readyState === 'complete') {
        resolve();
      } else {
        window.addEventListener('load', resolve, { once: true });
      }
    });
  }
  
  async typeText(element, text) {
    element.focus();
    
    // Type character by character for better compatibility
    for (let i = 0; i < text.length; i++) {
      element.value += text[i];
      element.dispatchEvent(new KeyboardEvent('keydown', { key: text[i] }));
      element.dispatchEvent(new KeyboardEvent('keyup', { key: text[i] }));
      
      // Small delay between characters
      if (i % 10 === 0) {
        await this.wait(10);
      }
    }
  }
  
  // Create new instance for use in content scripts
  static create() {
    return new NotebookLMAPI();
  }
}

// Export for use in other scripts
if (typeof window !== 'undefined') {
  window.NotebookLMAPI = NotebookLMAPI;
}

console.log('NotebookLM API utilities loaded');