// NotebookLM API Utilities
// Handles automation and interaction with NotebookLM interface

class NotebookLMAPI {
  constructor() {
    this.selectors = {
      // Authentication
      loginButton: '[data-testid*="sign-in"], [aria-label*="Sign in"], button:contains("Sign in")',
      
      // Navigation
      notebooksGrid: '[data-testid*="notebook"], .notebook-grid, [class*="notebook-list"]',
      notebookCard: '.notebook-card, [data-testid*="notebook-card"]',
      createNotebookButton: '[data-testid*="create"], button:contains("Create"), button[aria-label*="Create"]',
      
      // Sources
      addSourceButton: '[data-testid*="add"], button[aria-label*="Add"], button:contains("Add source")',
      sourceModal: '[role="dialog"], .modal, [data-testid*="modal"]',
      sourceTypeButtons: '[data-testid*="source-type"], .source-type-button',
      
      // Input fields
      urlInput: 'input[type="url"], input[placeholder*="URL"], input[placeholder*="url"]',
      textInput: 'textarea, [contenteditable="true"], input[type="text"]',
      titleInput: 'input[placeholder*="title"], input[placeholder*="Title"]',
      
      // Actions
      submitButton: 'button[type="submit"], button:contains("Add"), button:contains("Submit"), button:contains("Save")',
      cancelButton: 'button:contains("Cancel"), button[aria-label*="Cancel"]',
      
      // Status indicators
      successMessage: '[data-testid*="success"], .success-message, [class*="success"]',
      errorMessage: '[data-testid*="error"], .error-message, [class*="error"]',
      loadingIndicator: '[data-testid*="loading"], .loading, .spinner'
    };
    
    this.timeouts = {
      short: 2000,
      medium: 5000,
      long: 10000,
      veryLong: 20000
    };
  }
  
  // Main method to add content to NotebookLM
  async addContentToNotebook(content, notebookId = null) {
    try {
      console.log('Starting NotebookLM automation for content:', content.type);
      
      // Step 1: Verify we're on NotebookLM
      if (!this.isNotebookLMPage()) {
        throw new Error('Not on NotebookLM page');
      }
      
      // Step 2: Check authentication
      await this.ensureAuthenticated();
      
      // Step 3: Navigate to specific notebook or stay on current page
      if (notebookId) {
        await this.navigateToNotebook(notebookId);
      }
      
      // Step 4: Open add source dialog
      await this.openAddSourceDialog();
      
      // Step 5: Add the content based on type
      await this.addContentByType(content);
      
      // Step 6: Submit and verify
      const result = await this.submitAndVerify();
      
      console.log('Content added successfully to NotebookLM');
      return { success: true, result };
      
    } catch (error) {
      console.error('NotebookLM automation failed:', error);
      return { success: false, error: error.message };
    }
  }
  
  // Check if we're on a NotebookLM page
  isNotebookLMPage() {
    return window.location.hostname === 'notebooklm.google.com';
  }
  
  // Ensure user is authenticated
  async ensureAuthenticated() {
    // Check for sign-in button
    const loginButton = document.querySelector(this.selectors.loginButton);
    
    if (loginButton && loginButton.offsetParent !== null) {
      throw new Error('Please sign in to NotebookLM first. Click the extension when you are logged in.');
    }
    
    // Check for Google account picker or other auth indicators
    const accountPicker = document.querySelector('[data-account-picker], .account-picker, [role="listbox"]');
    if (accountPicker && accountPicker.offsetParent !== null) {
      throw new Error('Please complete Google account selection to access NotebookLM');
    }
    
    // Check if we're on an error page
    if (document.title.includes('Error') || document.body.textContent.includes('Access denied')) {
      throw new Error('Access denied to NotebookLM. Please check your account permissions.');
    }
    
    // Wait a moment for page to fully load
    await this.wait(this.timeouts.short);
    
    // Additional check - look for NotebookLM-specific elements
    const notebookElements = document.querySelectorAll('[data-testid*="notebook"], .notebook, [class*="notebook"]');
    if (notebookElements.length === 0 && !document.querySelector('.loading, [data-testid*="loading"]')) {
      // Give it more time to load
      await this.wait(this.timeouts.medium);
      
      const notebookElementsRetry = document.querySelectorAll('[data-testid*="notebook"], .notebook, [class*="notebook"]');
      if (notebookElementsRetry.length === 0) {
        throw new Error('NotebookLM interface not detected. Please ensure you are logged in and have access to NotebookLM.');
      }
    }
  }
  
  // Navigate to specific notebook
  async navigateToNotebook(notebookId) {
    const currentUrl = window.location.href;
    const targetUrl = `https://notebooklm.google.com/notebook/${notebookId}`;
    
    if (currentUrl !== targetUrl) {
      window.location.href = targetUrl;
      
      // Wait for navigation to complete
      await this.waitForPageLoad();
    }
  }
  
  // Open the add source dialog
  async openAddSourceDialog() {
    const addButton = await this.waitForElement(this.selectors.addSourceButton, this.timeouts.medium);
    
    if (!addButton) {
      throw new Error('Could not find Add Source button');
    }
    
    // Click the add source button
    addButton.click();
    
    // Wait for modal to appear
    const modal = await this.waitForElement(this.selectors.sourceModal, this.timeouts.medium);
    
    if (!modal) {
      throw new Error('Add source dialog did not open');
    }
    
    console.log('Add source dialog opened');
  }
  
  // Add content based on its type
  async addContentByType(content) {
    switch (content.type) {
      case 'youtube':
      case 'pdf':
        await this.addUrlContent(content);
        break;\n        \n      case 'article':\n      case 'webpage':\n        await this.addTextContent(content);\n        break;\n        \n      case 'selection':\n        await this.addTextContent(content);\n        break;\n        \n      default:\n        await this.addTextContent(content);\n    }\n  }\n  \n  // Add URL-based content (YouTube, PDF)\n  async addUrlContent(content) {\n    console.log('Adding URL content:', content.url);\n    \n    // Look for URL source type button first\n    const urlTypeButton = document.querySelector('[data-testid*=\"url\"], button:contains(\"URL\"), button:contains(\"Link\")');\n    if (urlTypeButton) {\n      urlTypeButton.click();\n      await this.wait(1000);\n    }\n    \n    // Find URL input field\n    const urlInput = await this.waitForElement(this.selectors.urlInput, this.timeouts.short);\n    \n    if (urlInput) {\n      // Clear and enter URL\n      urlInput.value = '';\n      urlInput.focus();\n      await this.typeText(urlInput, content.url);\n      \n      // Trigger input events\n      urlInput.dispatchEvent(new Event('input', { bubbles: true }));\n      urlInput.dispatchEvent(new Event('change', { bubbles: true }));\n    } else {\n      // Fallback to text input\n      await this.addTextContent(content);\n    }\n  }\n  \n  // Add text-based content\n  async addTextContent(content) {\n    console.log('Adding text content, length:', content.text?.length || 0);\n    \n    // Look for text source type button\n    const textTypeButton = document.querySelector('[data-testid*=\"text\"], button:contains(\"Text\"), button:contains(\"Paste\")');\n    if (textTypeButton) {\n      textTypeButton.click();\n      await this.wait(1000);\n    }\n    \n    // Find text input area\n    const textInput = await this.waitForElement(this.selectors.textInput, this.timeouts.short);\n    \n    if (!textInput) {\n      throw new Error('Could not find text input field');\n    }\n    \n    // Prepare content text\n    let contentText = '';\n    \n    if (content.type === 'article' || content.type === 'webpage') {\n      contentText = this.formatArticleContent(content);\n    } else if (content.type === 'selection') {\n      contentText = content.text || '';\n    } else {\n      contentText = content.text || content.description || content.url || '';\n    }\n    \n    // Truncate if too long\n    if (contentText.length > 50000) {\n      contentText = contentText.substring(0, 50000) + '\\n\\n[Content truncated]';\n    }\n    \n    // Clear and enter content\n    if (textInput.tagName.toLowerCase() === 'textarea') {\n      textInput.value = contentText;\n    } else {\n      textInput.textContent = contentText;\n      textInput.innerText = contentText;\n    }\n    \n    // Trigger events\n    textInput.focus();\n    textInput.dispatchEvent(new Event('input', { bubbles: true }));\n    textInput.dispatchEvent(new Event('change', { bubbles: true }));\n  }\n  \n  // Format article content for NotebookLM\n  formatArticleContent(content) {\n    let formatted = '';\n    \n    // Add title\n    if (content.title) {\n      formatted += `# ${content.title}\\n\\n`;\n    }\n    \n    // Add source URL\n    if (content.url) {\n      formatted += `Source: ${content.url}\\n\\n`;\n    }\n    \n    // Add metadata\n    if (content.author) {\n      formatted += `Author: ${content.author}\\n`;\n    }\n    \n    if (content.publishedAt) {\n      formatted += `Published: ${content.publishedAt}\\n`;\n    }\n    \n    if (content.readingTime) {\n      formatted += `Reading time: ${content.readingTime} min\\n`;\n    }\n    \n    if (content.author || content.publishedAt || content.readingTime) {\n      formatted += '\\n';\n    }\n    \n    // Add description if available\n    if (content.description && content.description !== content.title) {\n      formatted += `${content.description}\\n\\n`;\n    }\n    \n    // Add main content\n    if (content.markdown) {\n      formatted += content.markdown;\n    } else if (content.text) {\n      formatted += content.text;\n    }\n    \n    return formatted;\n  }\n  \n  // Submit the form and verify success\n  async submitAndVerify() {\n    console.log('Submitting content to NotebookLM');\n    \n    // Find and click submit button\n    const submitButton = await this.waitForElement(this.selectors.submitButton, this.timeouts.short);\n    \n    if (!submitButton) {\n      throw new Error('Could not find submit button');\n    }\n    \n    submitButton.click();\n    \n    // Wait for submission to complete\n    await this.wait(this.timeouts.medium);\n    \n    // Check for success or error messages\n    const successMessage = document.querySelector(this.selectors.successMessage);\n    const errorMessage = document.querySelector(this.selectors.errorMessage);\n    \n    if (errorMessage && errorMessage.offsetParent !== null) {\n      throw new Error(`NotebookLM error: ${errorMessage.textContent}`);\n    }\n    \n    // Wait a bit more for the UI to update\n    await this.wait(this.timeouts.short);\n    \n    return {\n      success: true,\n      timestamp: Date.now()\n    };\n  }\n  \n  // Get list of available notebooks\n  async getNotebooks() {\n    try {\n      // Navigate to notebooks list if not already there\n      if (!window.location.pathname.includes('/notebooks')) {\n        window.location.href = 'https://notebooklm.google.com/notebooks';\n        await this.waitForPageLoad();\n      }\n      \n      // Wait for notebooks to load\n      await this.waitForElement(this.selectors.notebooksGrid, this.timeouts.medium);\n      \n      const notebookCards = document.querySelectorAll(this.selectors.notebookCard);\n      const notebooks = [];\n      \n      notebookCards.forEach((card, index) => {\n        const titleElement = card.querySelector('h2, h3, .title, [data-testid*=\"title\"]');\n        const sourceCountElement = card.querySelector('[data-testid*=\"source\"], .source-count');\n        \n        if (titleElement) {\n          const notebook = {\n            id: this.extractNotebookId(card) || `notebook-${index}`,\n            name: titleElement.textContent.trim(),\n            sourceCount: this.extractSourceCount(sourceCountElement),\n            lastAccessed: Date.now()\n          };\n          \n          notebooks.push(notebook);\n        }\n      });\n      \n      console.log(`Found ${notebooks.length} notebooks`);\n      return notebooks;\n      \n    } catch (error) {\n      console.error('Failed to get notebooks:', error);\n      return [];\n    }\n  }\n  \n  // Extract notebook ID from card element\n  extractNotebookId(cardElement) {\n    // Try to find ID in various places\n    const link = cardElement.querySelector('a[href*=\"/notebook/\"]');\n    if (link) {\n      const match = link.href.match(/\\/notebook\\/([^?\\/]+)/);\n      if (match) return match[1];\n    }\n    \n    // Check data attributes\n    if (cardElement.dataset.notebookId) {\n      return cardElement.dataset.notebookId;\n    }\n    \n    return null;\n  }\n  \n  // Extract source count from element\n  extractSourceCount(element) {\n    if (!element) return 0;\n    \n    const text = element.textContent;\n    const match = text.match(/(\\d+)/);\n    return match ? parseInt(match[1]) : 0;\n  }\n  \n  // Utility methods\n  \n  async wait(milliseconds) {\n    return new Promise(resolve => setTimeout(resolve, milliseconds));\n  }\n  \n  async waitForElement(selector, timeout = 5000) {\n    const startTime = Date.now();\n    \n    while (Date.now() - startTime < timeout) {\n      const element = document.querySelector(selector);\n      if (element && element.offsetParent !== null) {\n        return element;\n      }\n      await this.wait(100);\n    }\n    \n    return null;\n  }\n  \n  async waitForPageLoad() {\n    return new Promise((resolve) => {\n      if (document.readyState === 'complete') {\n        resolve();\n      } else {\n        window.addEventListener('load', resolve, { once: true });\n      }\n    });\n  }\n  \n  async typeText(element, text) {\n    element.focus();\n    \n    // Type character by character for better compatibility\n    for (let i = 0; i < text.length; i++) {\n      element.value += text[i];\n      element.dispatchEvent(new KeyboardEvent('keydown', { key: text[i] }));\n      element.dispatchEvent(new KeyboardEvent('keyup', { key: text[i] }));\n      \n      // Small delay between characters\n      if (i % 10 === 0) {\n        await this.wait(10);\n      }\n    }\n  }\n  \n  // Create new instance for use in content scripts\n  static create() {\n    return new NotebookLMAPI();\n  }\n}\n\n// Export for use in other scripts\nif (typeof window !== 'undefined') {\n  window.NotebookLMAPI = NotebookLMAPI;\n}\n\nconsole.log('NotebookLM API utilities loaded');"