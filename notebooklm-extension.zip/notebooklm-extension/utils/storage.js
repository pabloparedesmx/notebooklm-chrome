// Storage Management Utilities
// Handles Chrome storage operations and data management

class StorageManager {
  constructor() {
    this.storage = chrome.storage.sync;
    this.localStorage = chrome.storage.local;
    
    // Storage keys
    this.keys = {
      USER_SETTINGS: 'userSettings',
      NOTEBOOKS: 'notebooks',
      RECENT_SOURCES: 'recentSources',
      CACHE_METADATA: 'cacheMetadata',
      EXTRACTION_CACHE: 'extractionCache'
    };
    
    // Default settings schema
    this.defaultSettings = {
      defaultNotebook: '',
      autoExtractContent: true,
      excludeNavigation: true,
      excludeAds: true,
      enableSmartExtraction: true,
      preferMarkdown: false,
      autoOpenNotebook: false,
      showExtractionPreview: true,
      extractionTimeout: 30,
      maxContentLength: 50000
    };
    
    // Cache settings
    this.cacheSettings = {
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
      maxEntries: 100,
      cleanupInterval: 60 * 60 * 1000 // 1 hour
    };
  }
  
  // Settings management
  
  async getSettings() {
    try {
      const result = await this.storage.get(this.keys.USER_SETTINGS);
      return { ...this.defaultSettings, ...result[this.keys.USER_SETTINGS] };
    } catch (error) {
      console.error('Failed to get settings:', error);
      return this.defaultSettings;
    }
  }
  
  async saveSettings(settings) {
    try {
      const mergedSettings = { ...this.defaultSettings, ...settings };
      await this.storage.set({ [this.keys.USER_SETTINGS]: mergedSettings });
      return { success: true };
    } catch (error) {
      console.error('Failed to save settings:', error);
      return { success: false, error: error.message };
    }
  }
  
  async resetSettings() {
    try {
      await this.storage.set({ [this.keys.USER_SETTINGS]: this.defaultSettings });
      return { success: true };
    } catch (error) {
      console.error('Failed to reset settings:', error);
      return { success: false, error: error.message };
    }
  }
  
  // Notebooks management
  
  async getNotebooks() {
    try {
      const result = await this.storage.get(this.keys.NOTEBOOKS);
      const notebooks = result[this.keys.NOTEBOOKS] || [];
      
      // Sort by last accessed date
      notebooks.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
      
      return { success: true, notebooks };
    } catch (error) {
      console.error('Failed to get notebooks:', error);
      return { success: false, error: error.message, notebooks: [] };
    }
  }
  
  async saveNotebooks(notebooks) {
    try {
      // Add timestamp to each notebook
      const timestampedNotebooks = notebooks.map(notebook => ({
        ...notebook,
        lastUpdated: Date.now()
      }));
      
      await this.storage.set({ [this.keys.NOTEBOOKS]: timestampedNotebooks });
      
      // Update cache metadata
      await this.updateCacheMetadata(this.keys.NOTEBOOKS);
      
      return { success: true };
    } catch (error) {
      console.error('Failed to save notebooks:', error);
      return { success: false, error: error.message };
    }
  }
  
  async updateNotebook(notebookId, updates) {\n    try {\n      const { notebooks } = await this.getNotebooks();\n      const index = notebooks.findIndex(nb => nb.id === notebookId);\n      \n      if (index === -1) {\n        return { success: false, error: 'Notebook not found' };\n      }\n      \n      notebooks[index] = { ...notebooks[index], ...updates, lastAccessed: Date.now() };\n      \n      return await this.saveNotebooks(notebooks);\n    } catch (error) {\n      console.error('Failed to update notebook:', error);\n      return { success: false, error: error.message };\n    }\n  }\n  \n  // Recent sources management\n  \n  async getRecentSources(limit = 10) {\n    try {\n      const result = await this.storage.get(this.keys.RECENT_SOURCES);\n      const sources = result[this.keys.RECENT_SOURCES] || [];\n      \n      // Filter out expired sources (older than 30 days)\n      const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);\n      const validSources = sources.filter(source => source.addedAt > thirtyDaysAgo);\n      \n      // Sort by date (newest first) and limit\n      const limitedSources = validSources\n        .sort((a, b) => b.addedAt - a.addedAt)\n        .slice(0, limit);\n      \n      return { success: true, sources: limitedSources };\n    } catch (error) {\n      console.error('Failed to get recent sources:', error);\n      return { success: false, error: error.message, sources: [] };\n    }\n  }\n  \n  async addRecentSource(source) {\n    try {\n      const { sources } = await this.getRecentSources(50); // Get more for processing\n      \n      // Check if source already exists (by URL)\n      const existingIndex = sources.findIndex(s => s.url === source.url);\n      \n      if (existingIndex !== -1) {\n        // Update existing source\n        sources[existingIndex] = { ...sources[existingIndex], ...source, addedAt: Date.now() };\n      } else {\n        // Add new source at the beginning\n        sources.unshift({ ...source, addedAt: Date.now() });\n      }\n      \n      // Keep only the most recent 50 sources\n      const limitedSources = sources.slice(0, 50);\n      \n      await this.storage.set({ [this.keys.RECENT_SOURCES]: limitedSources });\n      \n      return { success: true };\n    } catch (error) {\n      console.error('Failed to add recent source:', error);\n      return { success: false, error: error.message };\n    }\n  }\n  \n  async removeRecentSource(url) {\n    try {\n      const { sources } = await this.getRecentSources(100);\n      const filteredSources = sources.filter(source => source.url !== url);\n      \n      await this.storage.set({ [this.keys.RECENT_SOURCES]: filteredSources });\n      \n      return { success: true };\n    } catch (error) {\n      console.error('Failed to remove recent source:', error);\n      return { success: false, error: error.message };\n    }\n  }\n  \n  async clearRecentSources() {\n    try {\n      await this.storage.remove(this.keys.RECENT_SOURCES);\n      return { success: true };\n    } catch (error) {\n      console.error('Failed to clear recent sources:', error);\n      return { success: false, error: error.message };\n    }\n  }\n  \n  // Cache management\n  \n  async getCachedContent(url) {\n    try {\n      const cacheKey = this.generateCacheKey(url);\n      const result = await this.localStorage.get(cacheKey);\n      const cachedData = result[cacheKey];\n      \n      if (!cachedData) {\n        return null;\n      }\n      \n      // Check if cache is expired\n      if (Date.now() - cachedData.timestamp > this.cacheSettings.maxAge) {\n        await this.localStorage.remove(cacheKey);\n        return null;\n      }\n      \n      return cachedData.content;\n    } catch (error) {\n      console.error('Failed to get cached content:', error);\n      return null;\n    }\n  }\n  \n  async setCachedContent(url, content) {\n    try {\n      const cacheKey = this.generateCacheKey(url);\n      const cacheData = {\n        content,\n        timestamp: Date.now(),\n        url\n      };\n      \n      await this.localStorage.set({ [cacheKey]: cacheData });\n      \n      // Update cache metadata\n      await this.updateCacheMetadata('content_cache');\n      \n      // Cleanup old cache entries if needed\n      await this.cleanupCache();\n      \n      return { success: true };\n    } catch (error) {\n      console.error('Failed to cache content:', error);\n      return { success: false, error: error.message };\n    }\n  }\n  \n  generateCacheKey(url) {\n    // Create a hash-like key from URL\n    return 'cache_' + btoa(url).replace(/[^a-zA-Z0-9]/g, '').substring(0, 32);\n  }\n  \n  async updateCacheMetadata(cacheType) {\n    try {\n      const result = await this.localStorage.get(this.keys.CACHE_METADATA);\n      const metadata = result[this.keys.CACHE_METADATA] || {};\n      \n      metadata[cacheType] = {\n        lastUpdated: Date.now(),\n        count: (metadata[cacheType]?.count || 0) + 1\n      };\n      \n      await this.localStorage.set({ [this.keys.CACHE_METADATA]: metadata });\n    } catch (error) {\n      console.error('Failed to update cache metadata:', error);\n    }\n  }\n  \n  async cleanupCache() {\n    try {\n      // Get all local storage data\n      const allData = await this.localStorage.get(null);\n      \n      // Find cache entries\n      const cacheEntries = Object.entries(allData)\n        .filter(([key]) => key.startsWith('cache_'))\n        .map(([key, value]) => ({ key, ...value }))\n        .sort((a, b) => a.timestamp - b.timestamp); // Oldest first\n      \n      // Remove expired entries\n      const expiredKeys = cacheEntries\n        .filter(entry => Date.now() - entry.timestamp > this.cacheSettings.maxAge)\n        .map(entry => entry.key);\n      \n      if (expiredKeys.length > 0) {\n        await this.localStorage.remove(expiredKeys);\n        console.log(`Cleaned up ${expiredKeys.length} expired cache entries`);\n      }\n      \n      // Remove excess entries if over limit\n      const remainingEntries = cacheEntries.filter(entry => \n        Date.now() - entry.timestamp <= this.cacheSettings.maxAge\n      );\n      \n      if (remainingEntries.length > this.cacheSettings.maxEntries) {\n        const excessKeys = remainingEntries\n          .slice(0, remainingEntries.length - this.cacheSettings.maxEntries)\n          .map(entry => entry.key);\n        \n        await this.localStorage.remove(excessKeys);\n        console.log(`Cleaned up ${excessKeys.length} excess cache entries`);\n      }\n    } catch (error) {\n      console.error('Cache cleanup failed:', error);\n    }\n  }\n  \n  async clearAllCache() {\n    try {\n      // Get all local storage data\n      const allData = await this.localStorage.get(null);\n      \n      // Find cache entries\n      const cacheKeys = Object.keys(allData).filter(key => \n        key.startsWith('cache_') || key === this.keys.CACHE_METADATA\n      );\n      \n      if (cacheKeys.length > 0) {\n        await this.localStorage.remove(cacheKeys);\n        console.log(`Cleared ${cacheKeys.length} cache entries`);\n      }\n      \n      return { success: true };\n    } catch (error) {\n      console.error('Failed to clear cache:', error);\n      return { success: false, error: error.message };\n    }\n  }\n  \n  // Data export/import\n  \n  async exportData() {\n    try {\n      const syncData = await this.storage.get(null);\n      const localData = await this.localStorage.get(null);\n      \n      const exportData = {\n        version: '1.0.0',\n        timestamp: new Date().toISOString(),\n        sync: syncData,\n        local: localData\n      };\n      \n      return { success: true, data: exportData };\n    } catch (error) {\n      console.error('Failed to export data:', error);\n      return { success: false, error: error.message };\n    }\n  }\n  \n  async importData(importData) {\n    try {\n      if (!importData.version || !importData.sync) {\n        throw new Error('Invalid import data format');\n      }\n      \n      // Clear existing data\n      await this.storage.clear();\n      await this.localStorage.clear();\n      \n      // Import sync data\n      if (importData.sync && Object.keys(importData.sync).length > 0) {\n        await this.storage.set(importData.sync);\n      }\n      \n      // Import local data (excluding cache for security)\n      if (importData.local) {\n        const localDataToImport = {};\n        Object.entries(importData.local).forEach(([key, value]) => {\n          if (!key.startsWith('cache_') && key !== this.keys.CACHE_METADATA) {\n            localDataToImport[key] = value;\n          }\n        });\n        \n        if (Object.keys(localDataToImport).length > 0) {\n          await this.localStorage.set(localDataToImport);\n        }\n      }\n      \n      return { success: true };\n    } catch (error) {\n      console.error('Failed to import data:', error);\n      return { success: false, error: error.message };\n    }\n  }\n  \n  // Storage statistics\n  \n  async getStorageStats() {\n    try {\n      const syncData = await this.storage.get(null);\n      const localData = await this.localStorage.get(null);\n      \n      const stats = {\n        sync: {\n          bytesUsed: JSON.stringify(syncData).length,\n          itemCount: Object.keys(syncData).length\n        },\n        local: {\n          bytesUsed: JSON.stringify(localData).length,\n          itemCount: Object.keys(localData).length\n        },\n        cache: {\n          entries: Object.keys(localData).filter(key => key.startsWith('cache_')).length\n        }\n      };\n      \n      // Add quota information if available\n      if (chrome.storage.sync.QUOTA_BYTES) {\n        stats.sync.quota = chrome.storage.sync.QUOTA_BYTES;\n        stats.sync.usage = (stats.sync.bytesUsed / stats.sync.quota * 100).toFixed(1) + '%';\n      }\n      \n      if (chrome.storage.local.QUOTA_BYTES) {\n        stats.local.quota = chrome.storage.local.QUOTA_BYTES;\n        stats.local.usage = (stats.local.bytesUsed / stats.local.quota * 100).toFixed(1) + '%';\n      }\n      \n      return { success: true, stats };\n    } catch (error) {\n      console.error('Failed to get storage stats:', error);\n      return { success: false, error: error.message };\n    }\n  }\n  \n  // Utility methods\n  \n  async clear() {\n    try {\n      await this.storage.clear();\n      await this.localStorage.clear();\n      return { success: true };\n    } catch (error) {\n      console.error('Failed to clear storage:', error);\n      return { success: false, error: error.message };\n    }\n  }\n  \n  // Initialize periodic cache cleanup\n  startCacheCleanup() {\n    setInterval(() => {\n      this.cleanupCache();\n    }, this.cacheSettings.cleanupInterval);\n  }\n  \n  // Static method to create instance\n  static create() {\n    const instance = new StorageManager();\n    instance.startCacheCleanup();\n    return instance;\n  }\n}\n\n// Export for use in other scripts\nif (typeof window !== 'undefined') {\n  window.StorageManager = StorageManager;\n} else if (typeof module !== 'undefined') {\n  module.exports = StorageManager;\n}\n\nconsole.log('Storage management utilities loaded');"