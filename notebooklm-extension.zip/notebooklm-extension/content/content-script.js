// NotebookLM Content Adder - Content Script
// Runs on all pages to detect content and communicate with extension

let pageContent = null;
let isContentExtracted = false;
let extractionIndicator = null;

// Initialize content script
(function() {
  console.log('NotebookLM Content Adder content script loaded on:', window.location.href);
  
  // Listen for messages from popup and background script
  chrome.runtime.onMessage.addListener(handleMessage);
  
  // Auto-extract content on page load if enabled
  checkAutoExtraction();
  
  // Set up mutation observer to detect dynamic content changes
  setupContentObserver();
})();

// Handle messages from other parts of the extension
function handleMessage(request, sender, sendResponse) {
  switch (request.action) {
    case 'extractContent':
      extractContent(request.options).then(sendResponse);
      break;
      
    case 'getPageContent':
      sendResponse({ content: pageContent, extracted: isContentExtracted });
      break;
      
    case 'showExtractPreview':
      showExtractionPreview(request.content);
      sendResponse({ success: true });
      break;
      
    case 'hideExtractPreview':
      hideExtractionPreview();
      sendResponse({ success: true });
      break;
      
    default:
      sendResponse({ error: 'Unknown action: ' + request.action });
  }
  
  return true; // Keep message channel open for async responses
}

// Main content extraction function
async function extractContent(options = {}) {
  try {
    showExtractionIndicator();
    
    const content = {
      url: window.location.href,
      title: document.title,
      domain: window.location.hostname,
      extractedAt: Date.now(),
      userAgent: navigator.userAgent
    };
    
    // Get user settings for extraction preferences
    const settings = await getUserSettings();
    
    // Detect content type and extract accordingly
    const contentType = detectContentType();
    content.type = contentType;
    
    switch (contentType) {
      case 'youtube':
        await extractYouTubeContent(content);
        break;
        
      case 'pdf':
        extractPDFContent(content);
        break;
        
      case 'article':
        await extractArticleContent(content, settings);
        break;
        
      case 'selection':
        extractSelectionContent(content, options.selection);
        break;
        
      default:
        await extractGenericContent(content, settings);
    }
    
    // Apply content filtering based on settings
    if (settings.excludeNavigation || settings.excludeAds) {
      filterContent(content, settings);
    }
    
    // Convert to markdown if preferred
    if (settings.preferMarkdown && content.html) {
      content.markdown = convertToMarkdown(content.html);
    }
    
    pageContent = content;
    isContentExtracted = true;
    
    hideExtractionIndicator();
    
    if (settings.showExtractionPreview) {
      showExtractionPreview(content);
    }
    
    return { success: true, content };
    
  } catch (error) {
    console.error('Content extraction failed:', error);
    hideExtractionIndicator();
    return { success: false, error: error.message };
  }
}

// Detect the type of content on the current page
function detectContentType() {
  const url = window.location.href;
  const hostname = window.location.hostname;
  
  // YouTube detection
  if (hostname === 'www.youtube.com' && url.includes('/watch')) {
    return 'youtube';
  }
  
  // PDF detection
  if (url.includes('.pdf') || document.contentType === 'application/pdf') {
    return 'pdf';
  }
  
  // Article detection (common article indicators)
  const articleIndicators = [
    'article', 'main', '.post', '.entry', '.content',
    '[role="main"]', '.article-body', '.post-content'
  ];
  
  const hasArticleStructure = articleIndicators.some(selector => 
    document.querySelector(selector)
  );
  
  if (hasArticleStructure) {
    return 'article';
  }
  
  return 'webpage';
}

// Extract YouTube video content
async function extractYouTubeContent(content) {
  content.type = 'youtube';
  
  // Extract video ID
  const urlParams = new URLSearchParams(window.location.search);
  content.videoId = urlParams.get('v');
  
  // Extract video title
  const titleElement = document.querySelector('h1.ytd-video-primary-info-renderer') ||
                      document.querySelector('h1[class*="title"]') ||
                      document.querySelector('.ytd-video-primary-info-renderer h1');
  
  if (titleElement) {
    content.title = titleElement.textContent.trim();
  }
  
  // Extract channel information
  const channelElement = document.querySelector('a.ytd-channel-name') ||
                        document.querySelector('[class*="channel-name"] a');
  
  if (channelElement) {
    content.channel = channelElement.textContent.trim();
    content.channelUrl = channelElement.href;
  }
  
  // Extract description
  const descriptionElement = document.querySelector('#description') ||
                            document.querySelector('.ytd-video-secondary-info-renderer #description');
  
  if (descriptionElement) {
    content.description = descriptionElement.textContent.trim();
  }
  
  // Extract video duration
  const durationElement = document.querySelector('.ytp-time-duration');
  if (durationElement) {
    content.duration = durationElement.textContent.trim();
  }
  
  // Extract view count
  const viewsElement = document.querySelector('.ytd-video-view-count-renderer');
  if (viewsElement) {
    content.views = viewsElement.textContent.trim();
  }
  
  // Try to get transcript if available
  try {
    const transcriptButton = document.querySelector('[aria-label*="transcript"]');
    if (transcriptButton) {
      // Note: YouTube transcript extraction would require more complex implementation
      content.hasTranscript = true;
    }
  } catch (e) {
    // Transcript not available
  }
}

// Extract PDF content
function extractPDFContent(content) {
  content.type = 'pdf';
  content.pdfUrl = window.location.href;
  
  // Try to extract title from URL or page title
  const urlPath = new URL(window.location.href).pathname;
  const filename = urlPath.split('/').pop();
  
  if (filename && filename.includes('.pdf')) {
    content.filename = filename;
    content.title = filename.replace('.pdf', '').replace(/[-_]/g, ' ');
  }
}

// Extract article content using intelligent selectors
async function extractArticleContent(content, settings) {
  content.type = 'article';
  
  // Try multiple strategies to find main content
  const contentSelectors = [
    'article',
    'main',
    '[role="main"]',
    '.post-content',
    '.entry-content',
    '.article-body',
    '.content',
    '.post',
    '.entry'
  ];
  
  let mainContent = null;
  
  for (const selector of contentSelectors) {
    const element = document.querySelector(selector);
    if (element && element.textContent.trim().length > 200) {
      mainContent = element;
      break;
    }
  }
  
  if (!mainContent) {
    // Fallback to body but with more filtering
    mainContent = document.body;
  }
  
  if (mainContent) {
    // Clone content for processing
    const contentClone = mainContent.cloneNode(true);
    
    // Remove unwanted elements
    const unwantedSelectors = [
      'script', 'style', 'noscript',
      'nav', 'header', 'footer',
      '.navigation', '.sidebar', '.menu',
      '.advertisement', '.ad', '.ads',
      '.social-share', '.comments',
      '.related-posts', '.newsletter-signup'
    ];
    
    unwantedSelectors.forEach(selector => {
      const elements = contentClone.querySelectorAll(selector);
      elements.forEach(el => el.remove());
    });
    
    // Extract text and HTML
    content.text = contentClone.textContent.trim();
    content.html = contentClone.innerHTML;
    
    // Extract structured data
    extractMetadata(content);
    
    // Calculate reading time
    const wordCount = content.text.split(/\s+/).length;
    content.wordCount = wordCount;
    content.readingTime = Math.ceil(wordCount / 200); // Assuming 200 WPM
  }
}

// Extract selected text content
function extractSelectionContent(content, selection) {
  content.type = 'selection';
  content.text = selection;
  content.selectedAt = Date.now();
  
  // Try to find the parent element of the selection
  const selection_obj = window.getSelection();
  if (selection_obj.rangeCount > 0) {
    const range = selection_obj.getRangeAt(0);
    const container = range.commonAncestorContainer;
    const parentElement = container.nodeType === Node.TEXT_NODE ? 
                         container.parentElement : container;
    
    // Get some context around the selection
    if (parentElement) {
      content.context = parentElement.textContent.trim();
      content.html = parentElement.innerHTML;
    }
  }
}

// Extract generic webpage content
async function extractGenericContent(content, settings) {
  content.type = 'webpage';
  
  // Use a scoring system to find the best content container
  const candidates = Array.from(document.querySelectorAll('div, section, article, main'));
  let bestCandidate = null;
  let bestScore = 0;
  
  candidates.forEach(candidate => {
    const score = scoreContentElement(candidate);
    if (score > bestScore && score > 50) {
      bestScore = score;
      bestCandidate = candidate;
    }
  });
  
  if (bestCandidate) {
    const contentClone = bestCandidate.cloneNode(true);
    
    // Clean up content
    const unwantedElements = contentClone.querySelectorAll(
      'script, style, nav, header, footer, .sidebar, .advertisement'
    );
    unwantedElements.forEach(el => el.remove());
    
    content.text = contentClone.textContent.trim();
    content.html = contentClone.innerHTML;
  } else {
    // Fallback to body with heavy filtering
    content.text = document.body.textContent.trim();
  }
  
  extractMetadata(content);
}

// Score content elements to find the main content
function scoreContentElement(element) {
  let score = 0;
  const text = element.textContent.trim();
  
  // Text length scoring
  score += Math.min(text.length / 100, 25);
  
  // Paragraph count scoring
  const paragraphs = element.querySelectorAll('p');
  score += paragraphs.length * 5;
  
  // Positive class names
  const positiveClasses = ['content', 'post', 'article', 'entry', 'main'];
  const className = (element.className || '').toLowerCase();
  positiveClasses.forEach(cls => {
    if (className.includes(cls)) score += 15;
  });
  
  // Negative class names
  const negativeClasses = ['sidebar', 'nav', 'menu', 'advertisement', 'footer', 'header'];
  negativeClasses.forEach(cls => {
    if (className.includes(cls)) score -= 20;
  });
  
  // Link density penalty
  const links = element.querySelectorAll('a');
  const linkTextLength = Array.from(links).reduce((sum, link) => sum + link.textContent.length, 0);
  const linkDensity = text.length > 0 ? linkTextLength / text.length : 0;
  score -= linkDensity * 30;
  
  return score;
}

// Extract metadata from the page
function extractMetadata(content) {
  // Meta description
  const metaDescription = document.querySelector('meta[name="description"]');
  if (metaDescription) {
    content.description = metaDescription.content;
  }
  
  // Meta keywords
  const metaKeywords = document.querySelector('meta[name="keywords"]');
  if (metaKeywords) {
    content.keywords = metaKeywords.content.split(',').map(k => k.trim());
  }
  
  // Author
  const metaAuthor = document.querySelector('meta[name="author"]') ||
                    document.querySelector('meta[property="article:author"]');
  if (metaAuthor) {
    content.author = metaAuthor.content;
  }
  
  // Published date
  const publishedTime = document.querySelector('meta[property="article:published_time"]') ||
                       document.querySelector('time[datetime]');
  if (publishedTime) {
    content.publishedAt = publishedTime.getAttribute('datetime') || publishedTime.content;
  }
  
  // Open Graph data
  const ogTitle = document.querySelector('meta[property="og:title"]');
  if (ogTitle) content.ogTitle = ogTitle.content;
  
  const ogDescription = document.querySelector('meta[property="og:description"]');
  if (ogDescription) content.ogDescription = ogDescription.content;
  
  const ogImage = document.querySelector('meta[property="og:image"]');
  if (ogImage) content.ogImage = ogImage.content;
  
  // Canonical URL
  const canonical = document.querySelector('link[rel="canonical"]');
  if (canonical) content.canonicalUrl = canonical.href;
}

// Filter content based on user settings
function filterContent(content, settings) {
  if (!content.html) return;
  
  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = content.html;
  
  if (settings.excludeNavigation) {
    const navElements = tempDiv.querySelectorAll('nav, .navigation, .menu, .breadcrumb');
    navElements.forEach(el => el.remove());
  }
  
  if (settings.excludeAds) {
    const adElements = tempDiv.querySelectorAll('.ad, .ads, .advertisement, .sponsored, [class*="ad-"]');
    adElements.forEach(el => el.remove());
  }
  
  content.html = tempDiv.innerHTML;
  content.text = tempDiv.textContent.trim();
}

// Simple markdown conversion (basic implementation)
function convertToMarkdown(html) {
  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = html;
  
  // Basic HTML to Markdown conversion
  let markdown = tempDiv.innerHTML;
  
  // Headers
  markdown = markdown.replace(/<h1[^>]*>(.*?)<\/h1>/gi, '# $1\n\n');
  markdown = markdown.replace(/<h2[^>]*>(.*?)<\/h2>/gi, '## $1\n\n');
  markdown = markdown.replace(/<h3[^>]*>(.*?)<\/h3>/gi, '### $1\n\n');
  
  // Paragraphs
  markdown = markdown.replace(/<p[^>]*>(.*?)<\/p>/gi, '$1\n\n');
  
  // Links
  markdown = markdown.replace(/<a[^>]*href="([^"]*)"[^>]*>(.*?)<\/a>/gi, '[$2]($1)');
  
  // Bold and italic
  markdown = markdown.replace(/<strong[^>]*>(.*?)<\/strong>/gi, '**$1**');
  markdown = markdown.replace(/<b[^>]*>(.*?)<\/b>/gi, '**$1**');
  markdown = markdown.replace(/<em[^>]*>(.*?)<\/em>/gi, '*$1*');
  markdown = markdown.replace(/<i[^>]*>(.*?)<\/i>/gi, '*$1*');
  
  // Lists
  markdown = markdown.replace(/<li[^>]*>(.*?)<\/li>/gi, '- $1\n');
  markdown = markdown.replace(/<ul[^>]*>(.*?)<\/ul>/gi, '$1\n');
  markdown = markdown.replace(/<ol[^>]*>(.*?)<\/ol>/gi, '$1\n');
  
  // Remove remaining HTML tags
  markdown = markdown.replace(/<[^>]*>/g, '');
  
  // Clean up extra whitespace
  markdown = markdown.replace(/\n\n+/g, '\n\n').trim();
  
  return markdown;
}

// Get user settings from storage
async function getUserSettings() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ action: 'getSettings' }, (response) => {
      if (response && response.success) {
        resolve(response.settings);
      } else {
        // Default settings if none found
        resolve({
          autoExtractContent: true,
          excludeNavigation: true,
          excludeAds: true,
          enableSmartExtraction: true,
          preferMarkdown: false,
          showExtractionPreview: true
        });
      }
    });
  });
}

// Check if auto-extraction should be performed
async function checkAutoExtraction() {
  const settings = await getUserSettings();
  
  if (settings.autoExtractContent && !isContentExtracted) {
    // Wait a bit for page to fully load
    setTimeout(() => {
      extractContent();
    }, 2000);
  }
}

// Set up mutation observer to detect content changes
function setupContentObserver() {
  const observer = new MutationObserver((mutations) => {
    let significantChange = false;
    
    mutations.forEach((mutation) => {
      if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        // Check if added nodes contain significant content
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE && 
              node.textContent && 
              node.textContent.length > 100) {
            significantChange = true;
          }
        });
      }
    });
    
    // Re-extract content if significant changes detected
    if (significantChange && isContentExtracted) {
      setTimeout(() => {
        extractContent();
      }, 1000);
    }
  });
  
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
}

// Show extraction indicator
function showExtractionIndicator() {
  if (extractionIndicator) return;
  
  extractionIndicator = document.createElement('div');
  extractionIndicator.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: #1976d2;
    color: white;
    padding: 8px 16px;
    border-radius: 4px;
    font-family: Arial, sans-serif;
    font-size: 12px;
    z-index: 10000;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
  `;
  extractionIndicator.textContent = 'Extracting content...';
  document.body.appendChild(extractionIndicator);
}

// Hide extraction indicator
function hideExtractionIndicator() {
  if (extractionIndicator) {
    extractionIndicator.remove();
    extractionIndicator = null;
  }
}

// Show extraction preview
function showExtractionPreview(content) {
  // Create preview overlay
  const preview = document.createElement('div');
  preview.id = 'notebooklm-content-preview';
  preview.style.cssText = `
    position: fixed;
    top: 50px;
    right: 20px;
    width: 350px;
    max-height: 400px;
    background: white;
    border: 1px solid #ddd;
    border-radius: 8px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.2);
    z-index: 10001;
    font-family: Arial, sans-serif;
    overflow: hidden;
  `;
  
  const header = document.createElement('div');
  header.style.cssText = `
    background: #1976d2;
    color: white;
    padding: 12px 16px;
    font-size: 14px;
    font-weight: bold;
    display: flex;
    justify-content: space-between;
    align-items: center;
  `;
  
  header.innerHTML = `
    <span>Content Extracted</span>
    <button onclick="this.closest('#notebooklm-content-preview').remove()" 
            style="background: none; border: none; color: white; cursor: pointer; font-size: 16px;">×</button>
  `;
  
  const body = document.createElement('div');
  body.style.cssText = `
    padding: 16px;
    max-height: 320px;
    overflow-y: auto;
  `;
  
  const contentInfo = `
    <div style="margin-bottom: 12px;">
      <strong>Type:</strong> ${content.type}<br>
      <strong>Title:</strong> ${content.title}<br>
      ${content.wordCount ? `<strong>Words:</strong> ${content.wordCount}<br>` : ''}
      ${content.readingTime ? `<strong>Reading time:</strong> ${content.readingTime} min<br>` : ''}
    </div>
    <div style="font-size: 12px; color: #666; max-height: 200px; overflow-y: auto; background: #f5f5f5; padding: 8px; border-radius: 4px;">
      ${content.text ? content.text.substring(0, 300) + '...' : 'No text content'}
    </div>
  `;
  
  body.innerHTML = contentInfo;
  
  preview.appendChild(header);
  preview.appendChild(body);
  
  // Remove existing preview if any
  const existing = document.getElementById('notebooklm-content-preview');
  if (existing) existing.remove();
  
  document.body.appendChild(preview);
  
  // Auto-hide after 10 seconds
  setTimeout(() => {
    if (document.getElementById('notebooklm-content-preview')) {
      preview.remove();
    }
  }, 10000);
}

// Hide extraction preview
function hideExtractionPreview() {
  const preview = document.getElementById('notebooklm-content-preview');
  if (preview) {
    preview.remove();
  }
}

console.log('NotebookLM Content Adder content script initialized');