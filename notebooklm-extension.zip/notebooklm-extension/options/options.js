// NotebookLM Content Adder - Options Page Script (Simplified)

class OptionsController {
  constructor() {
    this.settings = {};
    this.notebooks = [];
    
    this.initializeElements();
    this.setupEventListeners();
    this.initialize();
  }
  
  initializeElements() {
    // Status message
    this.statusMessage = document.getElementById('statusMessage');
    this.statusIcon = document.getElementById('statusIcon');
    this.statusText = document.getElementById('statusText');
    
    // General settings
    this.autoExtractContent = document.getElementById('autoExtractContent');
    this.showExtractionPreview = document.getElementById('showExtractionPreview');
    this.autoOpenNotebook = document.getElementById('autoOpenNotebook');
    
    // Content processing
    this.enableSmartExtraction = document.getElementById('enableSmartExtraction');
    this.excludeNavigation = document.getElementById('excludeNavigation');
    this.excludeAds = document.getElementById('excludeAds');
    this.preferMarkdown = document.getElementById('preferMarkdown');
    
    // Default notebook
    this.defaultNotebook = document.getElementById('defaultNotebook');
    this.refreshNotebooks = document.getElementById('refreshNotebooks');
    
    // Footer links
    this.helpLink = document.getElementById('helpLink');
    this.feedbackLink = document.getElementById('feedbackLink');
  }
  
  setupEventListeners() {
    // Settings change listeners
    const settingInputs = [
      this.autoExtractContent,
      this.showExtractionPreview,
      this.autoOpenNotebook,
      this.enableSmartExtraction,
      this.excludeNavigation,
      this.excludeAds,
      this.preferMarkdown
    ];
    
    settingInputs.forEach(input => {
      if (input) {
        input.addEventListener('change', () => this.handleSettingChange());
      }
    });
    
    if (this.defaultNotebook) {
      this.defaultNotebook.addEventListener('change', () => this.handleSettingChange());
    }
    
    if (this.refreshNotebooks) {
      this.refreshNotebooks.addEventListener('click', () => this.refreshNotebooksList());
    }
    
    if (this.helpLink) {
      this.helpLink.addEventListener('click', () => this.showHelp());
    }
    
    if (this.feedbackLink) {
      this.feedbackLink.addEventListener('click', () => this.openFeedback());
    }
  }
  
  async initialize() {
    try {
      await this.loadSettings();
      await this.loadNotebooks();
      this.updateUI();
      this.showStatus('success', 'Settings loaded successfully');
    } catch (error) {
      console.error('Options initialization failed:', error);
      this.showStatus('error', 'Failed to load settings');
    }
  }
  
  async loadSettings() {
    try {
      const response = await this.sendMessage({ action: 'getSettings' });
      
      if (response && response.success) {
        this.settings = response.settings;
      } else {
        // Use default settings
        this.settings = this.getDefaultSettings();
      }
    } catch (error) {
      console.error('Failed to load settings:', error);
      this.settings = this.getDefaultSettings();
    }
  }
  
  getDefaultSettings() {
    return {
      defaultNotebook: '',
      autoExtractContent: true,
      excludeNavigation: true,
      excludeAds: true,
      enableSmartExtraction: true,
      preferMarkdown: false,
      autoOpenNotebook: false,
      showExtractionPreview: true
    };
  }
  
  updateUI() {
    // Update checkbox states
    if (this.autoExtractContent) this.autoExtractContent.checked = this.settings.autoExtractContent || false;
    if (this.showExtractionPreview) this.showExtractionPreview.checked = this.settings.showExtractionPreview !== false;
    if (this.autoOpenNotebook) this.autoOpenNotebook.checked = this.settings.autoOpenNotebook || false;
    if (this.enableSmartExtraction) this.enableSmartExtraction.checked = this.settings.enableSmartExtraction !== false;
    if (this.excludeNavigation) this.excludeNavigation.checked = this.settings.excludeNavigation !== false;
    if (this.excludeAds) this.excludeAds.checked = this.settings.excludeAds !== false;
    if (this.preferMarkdown) this.preferMarkdown.checked = this.settings.preferMarkdown || false;
    
    // Update default notebook
    if (this.notebooks.length > 0 && this.defaultNotebook) {
      this.defaultNotebook.value = this.settings.defaultNotebook || '';
    }
  }
  
  async loadNotebooks() {
    try {
      const response = await this.sendMessage({ action: 'getNotebooks' });
      
      if (response && response.success) {
        this.notebooks = response.notebooks;
        this.populateNotebookDropdown();
      } else {
        this.notebooks = [];
        this.populateNotebookDropdown();
      }
    } catch (error) {
      console.error('Failed to load notebooks:', error);
      this.notebooks = [];
      this.populateNotebookDropdown();
    }
  }
  
  populateNotebookDropdown() {
    if (!this.defaultNotebook) return;
    
    this.defaultNotebook.innerHTML = '';
    
    // Add 'None' option
    const noneOption = document.createElement('option');
    noneOption.value = '';
    noneOption.textContent = 'None (always show popup)';
    this.defaultNotebook.appendChild(noneOption);
    
    if (this.notebooks.length === 0) {
      const noNotebooksOption = document.createElement('option');
      noNotebooksOption.value = '';
      noNotebooksOption.textContent = 'No notebooks found - Create one in NotebookLM';
      noNotebooksOption.disabled = true;
      this.defaultNotebook.appendChild(noNotebooksOption);
      return;
    }
    
    // Add notebook options
    this.notebooks.forEach(notebook => {
      const option = document.createElement('option');
      option.value = notebook.id;
      option.textContent = notebook.name + ' (' + (notebook.sourceCount || 0) + ' sources)';
      this.defaultNotebook.appendChild(option);
    });
    
    // Select current default
    this.defaultNotebook.value = this.settings.defaultNotebook || '';
  }
  
  async refreshNotebooksList() {
    try {
      this.showStatus('loading', 'Refreshing notebooks list...');
      await this.loadNotebooks();
      this.showStatus('success', 'Notebooks list refreshed');
    } catch (error) {
      console.error('Failed to refresh notebooks:', error);
      this.showStatus('error', 'Failed to refresh notebooks list');
    }
  }
  
  async handleSettingChange() {
    try {
      // Collect current settings from UI
      const newSettings = {
        defaultNotebook: this.defaultNotebook ? this.defaultNotebook.value : '',
        autoExtractContent: this.autoExtractContent ? this.autoExtractContent.checked : true,
        showExtractionPreview: this.showExtractionPreview ? this.showExtractionPreview.checked : true,
        autoOpenNotebook: this.autoOpenNotebook ? this.autoOpenNotebook.checked : false,
        enableSmartExtraction: this.enableSmartExtraction ? this.enableSmartExtraction.checked : true,
        excludeNavigation: this.excludeNavigation ? this.excludeNavigation.checked : true,
        excludeAds: this.excludeAds ? this.excludeAds.checked : true,
        preferMarkdown: this.preferMarkdown ? this.preferMarkdown.checked : false
      };
      
      // Save settings
      const response = await this.sendMessage({ 
        action: 'saveSettings', 
        settings: newSettings 
      });
      
      if (response && response.success) {
        this.settings = newSettings;
        this.showStatus('success', 'Settings saved successfully');
      } else {
        this.showStatus('error', 'Failed to save settings');
      }
    } catch (error) {
      console.error('Failed to save settings:', error);
      this.showStatus('error', 'Failed to save settings');
    }
  }
  
  showHelp() {
    const helpContent = 'NotebookLM Content Adder Help:\n\n' +
      'General Settings:\n' +
      '• Auto-extract: Automatically analyze pages when you visit them\n' +
      '• Show preview: Display extracted content before adding to NotebookLM\n' +
      '• Keep tab open: Do not auto-close NotebookLM after adding content\n\n' +
      'Content Processing:\n' +
      '• Smart extraction: Use advanced algorithms to find main content\n' +
      '• Exclude navigation: Remove menus, headers, footers from content\n' +
      '• Exclude ads: Remove advertising content\n' +
      '• Markdown format: Convert HTML to clean Markdown\n\n' +
      'For more help, check the extension documentation.';
    
    alert(helpContent);
  }
  
  openFeedback() {
    const subject = encodeURIComponent('NotebookLM Content Adder Feedback');
    const body = encodeURIComponent('Hi,\n\nI have feedback about the NotebookLM Content Adder extension:\n\n[Your feedback here]\n\nVersion: 1.0.0');
    
    window.open('mailto:feedback@example.com?subject=' + subject + '&body=' + body);
  }
  
  showStatus(type, message) {
    if (!this.statusMessage) return;
    
    const icons = {
      'success': '✅',
      'error': '❌',
      'warning': '⚠️',
      'loading': '⏳'
    };
    
    if (this.statusIcon) this.statusIcon.textContent = icons[type] || '';
    if (this.statusText) this.statusText.textContent = message;
    this.statusMessage.className = 'status-message status-' + type;
    this.statusMessage.classList.remove('hidden');
    
    // Auto-hide non-loading messages after 5 seconds
    if (type !== 'loading') {
      setTimeout(() => {
        this.statusMessage.classList.add('hidden');
      }, 5000);
    }
  }
  
  // Utility methods
  async sendMessage(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve(response);
        }
      });
    });
  }
}

// Initialize options page when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new OptionsController();
});

console.log('NotebookLM Content Adder options script loaded');