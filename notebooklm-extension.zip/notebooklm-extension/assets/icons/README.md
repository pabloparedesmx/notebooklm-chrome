# Icons

This directory contains the extension icons. You'll need to add the following icon files:

- `icon16.png` - 16x16 pixels (toolbar icon)
- `icon32.png` - 32x32 pixels (Windows computers often display this size)
- `icon48.png` - 48x48 pixels (extension management page)  
- `icon128.png` - 128x128 pixels (Chrome Web Store and installation)

## Icon Requirements

- Format: PNG with transparency
- Square aspect ratio
- Clean, simple design that works at small sizes
- Should represent NotebookLM or note-taking functionality
- Consider using colors that match Google's material design palette

## Creating Icons

You can:
1. Use an icon generator service like favicon.io
2. Create your own using design tools like Figma, Canva, or GIMP
3. Use the provided placeholder template below

For now, placeholder colored squares are created as temporary icons.